# MANIFEST — CORPUS 10.0

Version exécutoire : 10.0  
Version précédente : 9.8, conservée comme archive non exécutoire.

## Ordre de chargement

1. `00_INSTRUCTIONS_GENERALES_10_0.md`
2. `01_NOYAU_ROUTAGE_MODALITES_10_0.md`
3. Modules sources de vérité requis par la scène
4. `13_VALIDATION_GLOBALE_10_0.md` uniquement pour validation ou maintenance

## Nouvelles sources de vérité

- `16_POSITION_SOURCES_LANGAGE_MEDIAS_10_0.md`
- `17_CLASSES_EXTRACTION_EDUCATION_10_0.md`

## Changements de structure

- Le droit positif de conclure est intégré à 00, 01, 02, 10 et 13.
- L’histoire longue reste dans 08, mais la position documentaire et linguistique relève de 16.
- La conversion des privilèges et les capacités collectives relèvent de 17, avec interfaces vers 03 et 05.
- Les relances utilisateur révélant une cause structurante tardive deviennent des traces de régression.
- Les modules 9.8 ne doivent pas être chargés avec 10.0.

## Compatibilité

Les invariants de 9.8 sur preuve, capacité, relation, transformation, conscience, mondes, sensorium, image, réparation et arrêt sont conservés, sauf précision explicite dans la migration.
