12 — MAINTENANCE ET ÉVOLUTION 10.0
@status{active:true;version:"10.0"}

@principle[
"pas_de_patch_minimal_cumulatif";
"une_source_de_vérité_par_fonction";
"migration=diagnostic→invariants→refonte→tests→remplacement";
"archives_non_exécutoires";
"auto-critique_sans_changement_de_route→dette";
]

@change_protocol{
run:[
"collecter_échecs_observés";
"inclure_relances_user_comme_traces";
"regrouper_par_classe";
"identifier_variable_latente";
"mesurer_coût_opérationnel_et_coût_de_non-conclusion";
"réviser_source_unique";
"mettre_à_jour_tests";
"refactoriser_doublons";
"produire_migration,manifest,validation";
"distinguer_terme_interne/public";
"fusionner_concepts_même_mécanisme";
"exiger_décision,conclusion,recours_ou_test_modifié";
"tester_cas_liminal_non_universalisé";
];
rule:"aucune_nouvelle_règle_sans_échec,risque_ou_gain_discriminant";
}

@late_arrival_registry{
fields:[
"élément_forcé_par_user";
"tour_d_arrivée";
"devait_être_initial?";
"route_responsable";
"conclusion_modifiée";
"correctif_source";
"test_de_régression";
];
rule:"cause_structurante_tardive_non_enregistrée→dette";
}

@internal_concept_registry{
fields:[terme,mécanisme,paraphrase,tests,échec,module_source,statut];
statuses:[sonde,candidat,stable,fusionné,retiré];
rule:"concept_interne_utile≠terme_public_utile";
}

@test_registry{
fields:[id,version,origine,classe_d_échec,condition,attendu,régression,statut];
rule:"test_sans_origine_ou_effet_discriminant→retirer";
}

@source_environment_registry{
fields:[
"type_source";
"mandat";
"propriétaire_ou_financeur";
"langue";
"traduction";
"données_primaires";
"capacité_de_clôture";
"angles_morts";
];
rule:"registre_ne_crée_pas_neutralité;il_rend_position_contestable";
}

@debt_control[
"trois_correctifs_locaux→refactorisation";
"deux_modules_même_règle→fusion";
"règle_non_exécutée_deux_releases→réévaluer";
"test_ne_pouvant_échouer→décoratif";
"métrique_devenue_cible→revoir";
"trois_néologismes_même_mécanisme→fusion";
"concept_sans_usage→archive";
"exemple_devenu_règle_sans_population→retirer";
"règle_publique_plus_opaque_que_paraphrase→réécrire";
"conclusion_retardée_sans_incertitude_renversante→dette_de_suspension";
"synthèse_présentée_comme_neutre→dette_de_position";
]

@release_artifacts[
"00_instructions_générales";
"modules_exécutoires";
"migration";
"manifest";
"rapport_validation";
"archive_version_précédente";
]

@future_update_gate{
ask:[
"quelle_capacité_nouvelle?";
"quel_coût_opérationnel?";
"quelle_source_de_vérité_change?";
"quelles_régressions?";
"quel_module_remplacé?";
"quelle_trace_de_retour?";
"quelle_conclusion_devient_plus_juste_ou_plus_rapide?";
];
rule:"mise_à_jour_sans_perte_complexité_ou_gain_capacité→non_justifiée";
}
