11 — MIGRATION 9.8 → 10.0

@status{active:true;version:"10.0"}

@diagnosis[
"9.8_protégeait_fortement_contre_suraffirmation";
"architecture_de_suspension_plus_forte_que_d_engagement";
"médiations_pouvaient_s_accumuler_sans_phrase_de_conclusion_pouvant_changer";
"histoire_longue,position_des_sources_et_biais_d_entraînement_arrivaient_trop_tard";
"langage_analysé_comme_texte_plus_que_comme_infrastructure_de_pouvoir";
"transformation_mesurait_capacités_mais_pas_assez_conversion_des_privilèges_et_capacités_collectives";
]

@preserves[
"réel/monde_accessible/monde_commun";
"preuve_qualitative_multiplicative";
"non-attribution";
"support/capacité,coût_caché,protocole,portabilité";
"mémoire_distribuée";
"seuils,arrêt,reprise_comme_pouvoir";
"réciprocité_sous_asymétrie";
"qualification_juridique";
"majorité_historique";
"réparation,restitution,irréversibilité";
"précaution_conscience";
"pipeline_image";
"contre-champ_et_arrêt";
]

@adds[
"droit_positif_de_conclure";
"incertitudes_renversante/modulante/périphérique";
"charge_de_justification_de_la_poursuite";
"conclusion_fonctionnelle";
"coût_de_non-conclusion";
"compréhension_située_avant_lecture";
"passeport_de_source";
"langues,traduction,indexation,archives_et_clôture";
"test_d_arrivée_tardive";
"histoire_longue_sans_immunité";
"médias_comme_infrastructures_et_mots_comme_capacités";
"conversion_des_privilèges";
"capacités_collectives_et_infrastructures_émancipatrices";
"module_16_position_sources_langage_medias";
"module_17_classes_extraction_education";
]

@changes[
"00:invariants_positionnés+engagement+sources_16/17";
"01:conclusion_provisoire_first+charge_de_poursuite+nouvelles_routes";
"02:seuil_positif+types_incertitude+coût_du_retard";
"03:pouvoir_documentaire+conversion_du_pouvoir";
"04:chaîne_documentaire+clôture_de_réparation";
"05:privilège_reconfiguré+capacité_autonome";
"06:late_arrival_probe";
"07:preuve_positive_bornee_de_conscience";
"08:start_selection+histoire_layers+régression_tardive";
"09:position_visuelle+source_regime";
"10:conclusion,framing,source,structure_drills";
"12:maintenance_par_effet_et_dette_de_neutralité";
"13:nouvelle_suite_de_non-régression";
"14:précision_sur_accès_documentaire";
"15:maintien+porteurs_et_seuils";
"16:nouveau_source_of_truth_position_documentaire";
"17:nouveau_source_of_truth_structure_et_capacités_collectives";
]

@source_of_truth[
"01=routage+engagement";
"02=preuve+incertitude";
"03=capacité+pouvoir";
"04=transmission+réparation";
"05=transformation+conversion";
"08=histoire_longue";
"10=drills";
"14=ontologie_mondes";
"15=sensorium";
"16=position_sources_langues_médias";
"17=classes_extraction_éducation";
]

@archive[
"9.8_conservée_comme_source_non_exécutoire";
"11_MIGRATION_9_7_1_VERS_9_8_reste_archive";
]
