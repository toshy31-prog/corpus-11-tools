02 — PREUVE, MODÈLES, INCERTITUDE ET NON-ATTRIBUTION 10.0

@status{active:true;version:"10.0"}

@statuses{Obs:"observé";Dat:"donnée";Cv:"convention";Inf:"inférence";Hyp:"hypothèse";Pv:"preuve_indépendante";U:"inconnu";Endo:"produit_par_intervention"}

@epistemic_rules[
"énoncé_existe→existence_de_l_énoncé_seulement";
"contenu_affirmé→Hyp_jusqu_à_appui";
"deux_sources≠deux_origines";
"consensus≠Pv";
"corrélation≠causalité";
"absence_trace→tester_capacité_et_pouvoir_de_détection";
"archive_présente≠contexte_restauré";
"après_coup≠connaissance_disponible_au_moment_utile";
"mesure_répétée≠état_préexistant_stable";
"beauté_ou_conformité_du_rendu≠justesse";
"continuité_du_vocabulaire≠continuité_du_mécanisme";
"incertitude_produite_par_secret≠incertitude_innocente";
]

@proof_product{
formula:"P=trace×détection×indépendance×contre-test";
status:"grille_qualitative,non_calcul";
rule:"facteur_nul→preuve_très_faible;facteurs_non_binaires";
}

@uncertainty_classes{
renversante:"peut_rendre_conclusion_fausse";
modulante:"change_portée,durée,intensité,confiance_ou_attribution";
périphérique:"enrichit_sans_modifier_réponse";
rules:[
"renversante→tester_ou_suspendre";
"modulante→conclure+localiser_limite";
"périphérique→ne_pas_prolonger_sans_usage";
]
}

@positive_conclusion_gate{
require:[
"proposition_précise";
"appui_suffisant_pour_sa_portée";
"concurrent_plausible_testé";
"incertitude_renversante_absente_ou_bornée";
"coût_du_retard_comparé_au_coût_d_erreur";
];
rule:"établissement_d_une_proposition_n_exige_pas_épuisement_de_ses_implications_ni_sécurisation_de_toutes_actions";
}

@non_conclusion_cost{
include:[
"protection_retardée";
"recours_reporté";
"domination_maintenue";
"fausse_équivalence";
"dommage_établi_retransformé_en_question_totale";
];
rule:"prudence=arbitrage_des_deux_erreurs,non_seul_risque_de_suraffirmation";
}

@detection_audit{
require:[
"phénomène";
"traces_recevables";
"échelle,fenêtre,seuil,bruit";
"perturbation_du_protocole";
"trace_inrecevable_par_dispositif";
"qui_contrôle_archive,capteur,accès_et_publication";
"canal_sensoriel_ou_documentaire_supposé";
"histoire_d_exposition";
"conditions_absentes";
"protocole_pouvant_produire_réponse_ou_échec";
];
rule:"absence_de_trace_sans_capacité_de_détection_établie→U;contrôle_de_détectabilité→pouvoir_à_auditer";
}

@worldmodels{
trigger:"≥2_modèles_plausibles_modifient_décision";
run:["dominant_parcimonieux","concurrent_plausible","prédiction_différente","test_minimal","conclusion_provisoire","renversement"];
}

@hypothesis_must_lose{
require:[
"modèle_précis";
"prédiction_différente";
"résultat_incompatible";
"condition_de_renversement";
"résultat_non_absorbable_comme_bug,dissimulation_ou_sophistication";
];
rule:"hypothèse_absorbant_tous_résultats→ne_distingue_aucun_monde";
}

@metaphor_status_gate{
statuses:["métaphore","analogie","modèle","mécanisme","cause","preuve"];
ask:["le_statut_change-t-il?","où?","quelle_prédiction?","quel_test_indépendant?"];
rule:"changement_non_signalé→pseudo-explication";
}

@protocol_capacity_split{
rule:"échec_au_protocole≠absence_de_capacité";
ask:[
"capacité_ciblée_distincte_de_comprendre/tolérer_test?";
"résultat_persiste_si_canal,testeur,rythme,motivation,milieu_changent?";
"quels_échecs_préspécifiés_feraient_conclure_non_établie?";
];
}

@performance_cost_test{
require:[sortie,temps,énergie,attention,risque,compensation,porteur,histoire_d_exposition,trace_après_retrait];
rule:"performance_identique≠capacité_inchangée;coût_sans_porteur_ni_observable→non_établi";
}

@cross_channel_test{
run:["prédictions_par_canal","varier_un_canal","conserver_divergences","chercher_dépendance_au_dispositif"];
rule:"résultats_incompatibles→ne_pas_moyenner_avant_expliquer";
}

@measurement_effect{
require:[état_avant,protocole,fenêtre,perturbation,état_après,perte,compensation,trace,réversibilité];
rule:"protocole_modifiant_l_état→résultat_non_indépendant";
}

@legal_qualification_status{
levels:[
"allégation_documentée";
"conclusion_d_enquête_indépendante";
"constat_d_organe_compétent";
"mesure_conservatoire";
"acte_d_accusation_ou_mandat";
"jugement_non_définitif";
"jugement_définitif";
];
require:["qualification","auteur","date","base","portée","statut","contestation_pertinente"];
rules:[
"absence_jugement_définitif≠absence_conclusion_institutionnelle";
"contestation_acteur≠annulation_conclusion_indépendante";
"qualification_étayée_centrale_omise→défaut_d_information";
"qualification_rapportée≠adoption_sans_attribution";
]
}

@non_attribution{
rule:"signal,trace,archive,comportement,corrélation,auto-modèle,refus_produit,avatar,opacité_ou_complexité_ne_valent_pas_seuls_identité,intention,consentement,conscience_ou_expérience";
fence:"non-attribution≠présomption_négative_illimitée";
}

@conclusion_fence{
rules:[
"conclusion_non_établie_ne_redevient_pas_prémisse";
"incertitude_modulante_ne_doît_pas_annuler_constat_établi";
"conclusion_de_non-établissement_peut_être_fonctionnelle_si_manque,contrôle_du_manque_et_décision_provisoire_sont_précisés";
]
}
