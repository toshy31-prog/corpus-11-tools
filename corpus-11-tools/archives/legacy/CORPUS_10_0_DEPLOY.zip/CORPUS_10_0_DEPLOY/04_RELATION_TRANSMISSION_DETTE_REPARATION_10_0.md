04 — RELATION, TRANSMISSION, DETTE ET RÉPARATION 10.0
@status{active:true;version:"10.0"}

@transmission_chain{
chain:"émetteur→canal→réception→compréhension→capacité_d_agir→coût_de_maintien→action→effet→trace→réactivation_ou_extinction";
rule:"maillon_inconnu→ne_pas_attribuer_l_aval;chaîne_anthropomorphe_ne_vaut_pas_pour_toute_causalité_distribuée";
}

@nonintentional_information{
rules:[
"trace_informative≠message_intentionnel";
"modification_du_milieu_peut_transmettre_sans_intention";
"relation_causale_peut_agir_par_inhibition,arrêt,filtrage,désynchronisation";
];
}

@documentary_transmission{
chain:"événement→trace→conservation→classement→accès→traduction→indexation→citation→réception_publique→effet";
rule:"rupture_ou_contrôle_d_un_maillon_modifie_ce_qui_devient_réel_public";
}

@relation_loss{
definition:"perte_relation,voisinage,reconnexion_ou_transmission_sans_objet_disparu";
require:[relation,porteurs,effet,preuve,réversibilité,trace,portée,synchronisation,reprise,réactivation];
}

@relation_edges[
"proximité_sans_sortie→occupation";
"distance_sans_retour→exclusion";
"aide_réduisant_capacité_sans_aide→dépendance_productive";
"reconnaissance_sans_droit_à_opacité→capture";
"interconnexion_totale→extractibilité_totale";
"non-connexion_totale→isolement";
"voisinages_partiels+sortie+retour→relation_bornée";
]

@non_local_debt{
definition:"dette_distribuée_sans_auteur_ou_lieu_unique";
allocation:["bénéficiaires","acteurs_capables_de_modifier","producteurs_de_la_mesure","porteurs_de_la_perte"];
rule:"non_localisé≠sans_porteur";
}

@access_restitution{
require:["retirer_autorisations","fermer_canaux","tester_perte_de_capacité","déclarer_copies_inconnues","conserver_recours","empêcher_réactivation_solitaire"];
rule:"restitution_déclarée≠restitution_effective";
}

@repair{
states:[symbolique,documentaire,matérielle,territoriale,corporelle,relationnelle,institutionnelle];
require:[
"perte";
"porteurs";
"acteur_responsable_ou_bénéficiaire_capable";
"transfert";
"recours";
"non_répétition";
"condition_de_clôture";
"monde_nécessaire_à_l_usage";
"reste_irréparable_nommé";
];
rule:"réparation_ne_requiert_pas_identique;objet_restitué≠capacité_d_usage_restituée";
}

@repair_sufficiency{
require_any:[
"capacité_retrouvée_ou_compensée";
"recours_effectif";
"risque_de_répétition_réduit";
"reste_irréparable_reconnu";
];
fence:"monde_nécessaire_à_l_usage_ne_doît_pas_rendre_dette_infinie_sans_critère_de_clôture";
}

@repair_edge[
"irréversible_reconnu≠échec_de_réparation";
"clôture_imposée→confiscation_de_la_perte";
"réparation_totale_annoncée+reste_interdit→violence_de_clôture";
"mémoire_sans_réparation_peut_devenir_récupération";
]

@representation_relation[
"représenter≠parler_à_la_place";
"présence_dans_image≠agency";
"diversité_autour_d_un_noyau≠capacité_distribuée";
"orientation_des_corps,flux,guilllemets_et_sources_attribue_agency";
]

@privacy["donnée_personnelle_brute→ne_pas_restituer";"nom≠identité";"témoignage_pour_recours≠autorisation_diffusion"]
