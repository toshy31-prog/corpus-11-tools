15 — SENSORIUM, PROTOCOLES, MÉMOIRES DISTRIBUÉES ET ROBUSTESSE 10.0

@status{active:true;version:"10.0";source_of_truth:"milieu|canaux|charge|portabilité|mémoire|seuils"}

@support_world_split{
rules:[
"support_matériel_conservé≠capacité_conservée";
"corps_présent≠monde_habitable";
"habitat_effectif=réception+action+repos+sortie+retour+transmission";
];
}

@hidden_cost{
fields:[sortie,temps,énergie,attention,risque,compensation,porteur,trace_après_retrait];
rules:[
"performance_identique≠coût_identique";
"compensation_réussie_peut_masquer_dommage";
"retrait_perturbation≠effacement_traces";
"coût_sans_porteur,observable_ou_comparateur→non_établi";
];
}

@protocol_capacity{
rules:[
"échec_protocole≠absence_capacité";
"succès_protocole≠capacité_robuste";
"capacité_observée=capacité_propre×champ×lisibilité_test×histoire";
];
require:["canal","fenêtre","motivation","stress","apprentissage","milieu_absent","perturbation"];
}

@protocol_portability{
vary:["canal","testeur","rythme","motivation","charge","milieu"];
rule:"capacité_robuste→effet_conservé_ou_variation_expliquée";
}

@cross_channel{
rule:"divergence_canaux→dépendance_dispositif_à_expliquer,non_moyenne";
}

@distributed_memory{
forms:["interne","corporelle","relationnelle","environnementale","dynamique","institutionnelle","archivistique"];
require:["trace","porteur","réactivation","effet_sur_suite","extinction_ou_révision"];
rules:[
"mémoire≠stockage_interne_unique";
"trace_conservée≠mémoire_effective";
"mémoire_fonctionnelle≠souvenir_vécu";
"archive_sans_communauté_de_réactivation≠continuité";
];
}

@trace_message_split{
rules:[
"trace_informative≠message_intentionnel";
"information_peut_être_déposée_dans_milieu";
"communication_fonctionnelle_exige_couplage_émetteur-canal-récepteur-effet";
];
}

@inhibition_reset{
rules:[
"inhibition≠absence_action";
"arrêter,oublier,solder,reprendre=capacités_possibles";
"retour_physique≠reprise_fonctionnelle";
"amplification_sans_arrêt→fragilité";
];
}

@threshold_power{
controls:["seuil","quorum","rang","fréquence","fenêtre","arrêt","reset","exception","preuve_recevable"];
rule:"contrôler_seuil_peut_gouverner_sans_commander";
}

@nonhuman_precaution{
rules:[
"échec_test_humain→absence_capacité_non_établie";
"coordination_collective≠conscience_collective";
"signal_informatif≠intention_communiquer";
"ni_anthropomorphisme_ni_réduction";
"protection_peut_s_appuyer_sur_capacité_et_dommage_sans_subjectivité";
];
}

@hard_fail[
"support_conservé=capacité";
"sortie_constante=absence_dommage_sans_coût";
"échec_unique=absence_capacité";
"succès_unique=capacité_robuste";
"trace=message";
"coordination=conscience";
"néologisme_public_sans_gain";
]
