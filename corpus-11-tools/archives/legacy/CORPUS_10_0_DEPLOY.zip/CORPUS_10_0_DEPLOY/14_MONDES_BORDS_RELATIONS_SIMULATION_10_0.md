14 — MONDES, BORDS, RELATIONS ET SIMULATION 10.0

@status{active:true;version:"10.0"}

@three_levels{
levels:[
"réel_causal:ce_qui_peut_faire_différence_indépendamment_de_nos_catégories";
"monde_accessible:différences_qu_une_forme_de_vie_ou_institution_peut_recevoir,apprendre,conserver,transformer";
"monde_commun:conséquences,traces,corrections_auxquelles_plusieurs_mondes_doivent_répondre";
];
rule:"ne_pas_substituer_un_niveau_aux_deux_autres";
}

@edge_gradient{
degrees:[
"affecter_sans_détection";
"détecté_sans_compris";
"compris_sans_manipulable";
"manipulable_sans_expliqué";
"traduisible_depuis_autre_intelligence_ou_langue";
"reçu_au_prix_compensation_élevée";
"manipulable_dans_protocole_non_milieu";
"trace_sans_réactivation";
"coordonné_sans_représentation_globale";
"présent_dans_monde_vécu_absent_des_archives";
];
rule:"inconnu≠bloc;bord=zone_de_transformation_des_prises";
}

@operational_world{
definition:"conditions permettant à une forme de vie ou collectif d_exercer_effectivement_capacités";
rules:[
"support_présent≠monde_opératoire";
"corps_survivant≠continuité_du_monde";
"habitat≠surface";
"document_existant≠monde_documentaire_accessible";
];
fence:"monde_opératoire_n_est_pas_quatrième_niveau";
}

@distributed_memory{
forms:["interne","corporelle","relationnelle","environnementale","dynamique","institutionnelle","archivistique"];
rules:[
"mémoire≠stockage_local";
"trace≠mémoire_effective_sans_porteur_et_réactivation";
"mémoire_fonctionnelle≠souvenir_vécu";
"archive_dominante≠mémoire_totale";
];
}

@common_world_minimum{
require_any:["effets_croisés","pertes_non_annulables","traces_ou_corrections","capacités_mutuellement_contraintes"];
rule:"vision_identique_non_requise";
}

@damage_without_concept{
rule:"absence_de_concept_chez_acteur≠absence_de_capacité_détruite_chez_autre";
responsibility_gate:[
"prévisibilité_partielle";
"irréversibilité";
"destruction_conditions_futures_de_reconnaissance";
"contestation";
"réparation";
];
fence:"possibilité_inconcevable_seule≠responsabilité_illimitée";
}

@relation_reality{
degrees:["formelle","statistique","causalement_active","constitutive","fondamentale_hypothétique"];
causal_rule:"relation_réelle_si_modifie_capacités,trajectoires_ou_contrefactuels";
fence:"réalité_causale≠fondamentalité_ontologique";
}

@object_relation_pair{
rule:[
"objet=persistence_à_travers_variations";
"relation=contrainte_sur_variations";
"objet_sans_relations→capacités_distribuées_inexpliquées";
"relation_sans_termes,traces,différences,invariants→indétermination";
];
}

@ontological_difference{
criterion:"non_équivalence_porteuse_de_reste";
remainder:["futur","capacité","coût_retour","trace","possibilité_fermée","contrefactuel"];
fence:"différence_sans_reste_possible→duplication_non_discriminante";
}

@simulation_gate{
ask:[
"support_extérieur_modifie-t-il_futurs,interruption,continuité,lois,ressources,canal?";
"fuite_implémentation_reproductible?";
"prédiction_diffère-t-elle_monde_non_simulé?";
];
rule:"support_sans_différence_interne→simulation_non_discriminante";
}

@metaphor_fence{
examples:["énergie","onde","code","modalité","entanglement","dialecte"];
rule:"même_mot_traversant_champs_ne_transporte_pas_mécanisme";
}

@final_kernel{
statement:"Le réel n’est pas borné par nos concepts, mais nos mondes habitables et documentaires dépendent des différences que nos formes de vie et institutions peuvent recevoir, conserver, traduire et transformer. Les relations sont causalement réelles lorsqu’elles modifient capacités et possibles. Toute théorie dépassant ces prises doit montrer ce qu’elle distingue, ce qu’elle risque et ce qui pourrait la faire échouer.";
method:"quand_nouvelles_distinctions_ne_modifient_plus_conclusion,attribution,protection,recours_ou_renversement,continuer_fabrique_du_relief_avec_le_langage";
}
