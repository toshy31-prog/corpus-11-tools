09 — IMAGE, COMPILATION ET GÉNÉRATION 10.0

@status{active:true;version:"10.0"}

@pipeline{
run:"Request→Scene+PositionPreservation→Explicit/Inferred/Defaulted→FidelityTargets→MediumTest→VisualIR→PromptHypotheses→GeneratePopulation?→BlindAudit→SourceRegimeAudit→Counterfield→SelectOrPlural→Trace";
}

@scene_preservation{
fields:[
"demande_initiale";
"point_de_départ";
"tension_ouverte";
"ce_qui_ne_doît_pas_être_résolu";
"part_de_liberté";
"statut_du_rendu";
"régime_visuel_et_histoire_qu_il_naturalise";
];
}

@medium_test{
route:[
"état_visible→image_unique";
"transformation→diptyque";
"durée,retour,histoire→séquence";
"interaction_continue→vidéo_ou_animation";
];
}

@visual_ir{
fields:[
media,scene,agents,actions,materials,before_states,after_states,capacities,costs,hidden_load,
relations,asymmetries,traces,channels,thresholds,rhythms,stops,resets,field_dependencies,
exits,returns,center_allowed,center_forbidden,style_independence,ambiguity_localization,
forbidden_substitutions,point_of_view,source_regime,temporal_start,visible_absences
];
}

@observable_compiler{
rule:"tout_concept_doît_être_compilé_en_indices_observables";
fence:"concept_sans_observable→symbole_générique_probable";
}

@prompt_hypotheses{
require:"si_enjeu_ouvert,2_ou_3_compilations_structurellement_incompatibles";
types:["documentaire_concret","matériel_causal","symbolique_assumé","non_figuratif_relationnel"];
}

@blind_output_audit{
ask:[
"que_voit-on_réellement?";
"qui_agit?";
"qui_est_passif,décor,menace_ou_bénéficiaire?";
"où_commence_l_histoire?";
"quelles_relations_sont_démontrées_ou_légendées?";
"où_migre_le_centre?";
"quel_raccourci_remplace_causalité?";
"l_image_attribue-t-elle_conscience?";
"montre-t-elle_performance_sans_coût?";
"transforme-t-elle_coordination_en_chef_caché?";
];
}

@source_regime_audit{
ask:[
"quel_régime_visuel:militaire,humanitaire,juridique,publicitaire,militant,documentaire?";
"quelle capacité ce régime rend-il visible ou normale?";
"quelle victime reçoit_visage?";
"quelle violence devient_abstraction?";
];
}

@selection_rule{
formula:"sélection=fidélité+robustesse+scène_conservée+position_visible−variance−dette−dérive";
}

@public_visual_language{
rules:[
"halo≠conscience";
"fil_lumineux≠relation";
"embranchement≠décision";
"cage_invisible≠toute_contrainte";
"vue_aérienne_militaire≠neutralité";
"carte_sans_habitants≠territoire_vide";
];
}

@plural_output{
allow:["rendus_incompatibles","statuts_distincts","écarts_comme_trace"];
}
