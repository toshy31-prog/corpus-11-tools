# ATLAS 3.0 — VALIDATION FINALE

- Source : `atlas.atl`
- Blocs requis : 25
- Blocs trouvés : 25
- Blocs manquants : 0
- Instructions : 6294 caractères / 7 990
- Vues générées : Runtime, Eval, Maintenance, Self Model
- Couverture globale : **PASS**
- SHA-256 source : `21496524b4b1895d00868f507cc456b748dda27dc62ce65c02352205a4250460`

## Corrections intégrées
- `A_CTX != A_PKG`
- `D != PKG != CTX != EXE != VER`
- vue Évaluation générée
- convention obligatoire avant confiance numérique
- rapport de couverture par vue
- refus si instructions > 7 990 caractères
- statut 3.0 actif avec retour 2.7 archivé
