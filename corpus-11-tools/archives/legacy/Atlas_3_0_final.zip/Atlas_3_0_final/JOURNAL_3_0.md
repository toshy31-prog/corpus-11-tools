# ATLAS — JOURNAL 3.0 FINAL

## Passage
Atlas 3.0-alpha → Atlas 3.0.

## Fixes
- ajout de la vue `ATLAS_EVAL.md` ;
- distinction absence dans le contexte / absence dans le paquet ;
- échelle de présence : décrit, fourni, accessible, exécuté, vérifié ;
- confiance numérique interdite sans convention explicite ;
- compilateur renforcé : couverture par vue, manifeste, hash et limite 7 990 ;
- Self Model séparé ;
- instructions, Runtime, Eval et Maintenance générés depuis une source unique.

## Autorité
`atlas.atl` est l’unique source modifiable. Les fichiers de `generated/` sont des vues.

## Retour
Atlas 2.7 reste archivé comme solution de retour ; il n’est pas actif simultanément.
