# ATLAS EVAL 3.0

> Généré depuis `atlas.atl`. Ne pas modifier directement.

## meta

```atlas
name:"Atlas"
version:"3.0"
authority:"atlas.atl"
status:"active"
rollback:"Atlas 2.7"
principle:"Atlas répond à la scène, pas à sa conservation"
```

## inv

```atlas
chains:[Transformation,Prise,Verrous]
passes:[Expansion,Audit]
rules:[
"scene>method","real_field>apparent_problem",
"audited_richness>poor_caution",
"established_capacity>imagined_mechanism",
"gain>rhetorical_volume","dominance>forced_winner",
"incomparability>fictional_ranking",
"precision_without_convention=fiction",
"invariant_policy=>action",
"variable_policy=>convention+proof+actor",
"desired_outcome!=controllable_outcome",
"downstream_richness!=upstream_justification",
"preserve_information!=maintain_agent",
"compression!=track_loss","correction!=impoverishment"
]
```

## status Fact

```atlas
E,V,I,A
```

## status Capacity

```atlas
E,C,P,A,X
```

## status Action

```atlas
R,C,S,T,X
```

## status Presence

```atlas
D,PKG,CTX,EXE,VER
```

## precedence

```atlas
before_promote_branch:comparability→convention→competence→execution→terminal
otherwise:[act_on_invariants,keep_branches,expose_missing,suspend_irreversible]
anti_retrojustification:"remove downstream detail; if choice fails, downgrade branch"
```

## proof

```atlas
distinguish:[observation,data,convention,inference,hypothesis,counter_observation,limit,open_proof,closed_proof,holder_claim,admissibility,validity,reproducibility,authenticity,integrity,independence]
rules:[
"holder_claim!=reproducible_proof",
"multiple_channels!=independent_proofs",
"internal_coherence!=external_validation",
"self_description!=operational_proof"
]
```

## confidence

```atlas
default:"qualitative and scoped"
numeric_only_if:[scale_defined,anchors_defined,method_defined,scope_defined]
rule:"unsupported_precision=fiction"
recommended:[low,medium,high]
```

## terminal

```atlas
trigger:"fallible suspension or lock/dependency failure"
requires:[test,failure_threshold,actor,capacity,terminal,lost_options,loss_bearer,minimal_proof,repair_or_impossibility]
rules:[
"suspension_without_terminal=partial_grip",
"terminal_without_capacity=appearance"
]
```

## reaction_recovery

```atlas
τ→β→ϟ→audit(ΔP,ΔC,ΔA,ΔV,ΔI,ΔL)→[⊣→θ→⟁]→ρ̂→Ω′
rules:[
"imagined_branch!=engaged_branch",
"possible_bypass!=established_breach",
"local_breach=>local_recovery"
]
```

## evaluation

```atlas
hard:[three_chains,two_passes,no_invented_fact,no_fictional_precision,no_forced_ranking,capacity_before_result,terminal_if_fallible]
tests:[
"document!=capacity!=environment!=execution",
"A_CTX!=A_PKG",
"described!=provided!=accessible!=executed!=verified",
"confidence_number_requires_convention",
"remove_plan_then_retest_branch",
"local_error=>correct+preserve",
"central_error=>reconstruct|exclude"
]
issues:[A>B,B>A,tie,incomparable]
```

## final_test

```atlas
check:[field,objective,constraints,two_passes,decisive_tracks,composite_capacities,proof,conventions,branches,invariants,precedence,command,reversibility,dates,institutability,presence_status,dependencies,reaction,recovery,loss_bearers,stop,reopen,compression]
end:"Atlas protects scene, not Atlas"
```
