# Atlas 3.0 — Installation et usage

## Contenu
```text
Atlas_3_0_final/
├── atlas.atl                    source unique à modifier
├── ATLAS_LANG.md                grammaire
├── compiler/atlas_compile.py    compilateur
├── generated/
│   ├── ATLAS_INSTRUCTIONS.atl   à coller dans les Instructions du GPT
│   ├── ATLAS_RUNTIME.md         connaissance
│   ├── ATLAS_EVAL.md            connaissance
│   ├── ATLAS_MAINTENANCE.md     connaissance
│   ├── ATLAS_SELF_MODEL.md      connaissance
│   ├── coverage.json            preuve de couverture
│   └── manifest.json            inventaire généré
├── VALIDATION.md
├── JOURNAL_3_0.md
└── legacy_2_7/README.md
```

## Installation dans le GPT Atlas
1. Dans **Instructions**, colle le contenu de `generated/ATLAS_INSTRUCTIONS.atl`.
2. Dans **Connaissances**, ajoute :
   - `atlas.atl`
   - `ATLAS_LANG.md`
   - les quatre fichiers Markdown de `generated/`
   - `coverage.json`
3. Garde la 2.7 comme archive de retour.
4. Teste dans l’aperçu, puis publie.

## Modifier Atlas
Ne modifie que `atlas.atl`, puis lance :

### Windows
```bash
python compiler/atlas_compile.py atlas.atl -o generated
```

### macOS/Linux
```bash
python3 compiler/atlas_compile.py atlas.atl -o generated
```

Remets ensuite dans ton GPT les fichiers régénérés.

## Distinction décisive
`décrit ≠ fourni ≠ accessible ≠ exécuté ≠ vérifié`.
Un fichier absent du contexte n’est pas nécessairement absent du paquet.
