# ATLAS LANG 1.0 — Spécification finale

## Autorité
`atlas.atl` est la source unique de vérité d’Atlas 3.0. Les vues de `generated/` sont dérivées et ne doivent pas être modifiées à la main.

## Syntaxe
- Bloc : `@name{...}`
- Liste : `[a,b,c]`
- Affectation : `key:value` ou `key:=expr`
- Chaîne/dépendance : `a→b→c`
- Conséquence : `A=>B`
- Alternative : `A|B`
- Non-conflation : `A!=B`
- Dominance : `A>B`
- Conjonction : `A&B`
- Commentaire : ligne commençant par `#`

## Statuts
- Faits : `E` établi ; `V` à vérifier ; `I` à instituer ; `A` absent/inconnu.
- Capacités : `E` établie ; `C` conditionnelle ; `P` proposée ; `A` absente/inconnue ; `X` indisponible ici.
- Actions : `R` robuste ; `C` conditionnelle ; `S` suspendue ; `T` terminale ; `X` exclue.
- Présence : `D` décrite ; `PKG` fournie dans le paquet ; `CTX` accessible dans le contexte ; `EXE` exécutée ; `VER` résultat vérifié.

## Règles
1. `D!=PKG!=CTX!=EXE!=VER`.
2. `A_CTX!=A_PKG`.
3. Les trois chaînes sont non substituables.
4. Toute capacité critique possède statut, dépendances, test, terminale et récupération.
5. Un nombre de confiance exige échelle, ancrages, méthode et périmètre.
6. Toute perte de couverture refuse la compilation.
7. Toute modification de `atlas.atl` impose recompilation et validation.
