#!/usr/bin/env python3
"""Compilateur Atlas 3.0.
Valide atlas.atl et génère Instructions, Runtime, Eval, Maintenance,
Self Model, couverture et manifeste.
"""
from __future__ import annotations
import argparse, json, re, hashlib
from pathlib import Path

REQUIRED = {
 "meta","inv","chain Transformation","chain Prise","chain Verrous",
 "status Fact","status Capacity","status Action","status Presence",
 "pass Expansion","pass Audit","orchestration","patchbay","self_model",
 "precedence","command_contract","capacity_rule","proof","confidence",
 "terminal","reaction_recovery","stop_reopen","evaluation","upgrade","final_test"
}
VIEWS = {
 "ATLAS_RUNTIME.md":{
  "meta","inv","chain Transformation","chain Prise","chain Verrous",
  "status Fact","status Capacity","status Action","status Presence",
  "pass Expansion","pass Audit","orchestration","patchbay","self_model",
  "precedence","command_contract","capacity_rule","proof","confidence",
  "terminal","reaction_recovery","stop_reopen","final_test"},
 "ATLAS_EVAL.md":{
  "meta","inv","status Fact","status Capacity","status Action","status Presence",
  "proof","confidence","precedence","terminal","reaction_recovery",
  "evaluation","final_test"},
 "ATLAS_MAINTENANCE.md":{
  "meta","self_model","confidence","stop_reopen","upgrade","evaluation"},
 "ATLAS_SELF_MODEL.md":{
  "meta","status Presence","self_model","confidence","evaluation"}
}

def parse_blocks(text:str):
    blocks=[]; i=0
    while i<len(text):
        m=re.search(r'@([A-Za-z_]+(?:\s+[A-Za-z_]+)?)\{',text[i:])
        if not m: break
        name=m.group(1).strip(); start=i+m.end(); depth=1; j=start
        ins=False; esc=False
        while j<len(text) and depth:
            ch=text[j]
            if esc: esc=False
            elif ch=="\\": esc=True
            elif ch=='"': ins=not ins
            elif not ins:
                if ch=="{": depth+=1
                elif ch=="}": depth-=1
            j+=1
        if depth: raise ValueError(f"Bloc non fermé: {name}")
        blocks.append((name,text[start:j-1].strip())); i=j
    return blocks

def render(title, source_name, blocks, allowed):
    out=[f"# {title}\n\n> Généré depuis `{source_name}`. Ne pas modifier directement.\n"]
    for name,body in blocks:
        if name in allowed:
            out.append(f"\n## {name}\n\n```atlas\n{body}\n```\n")
    return "".join(out)

def compile_views(src:Path,out:Path):
    text=src.read_text(encoding="utf-8")
    blocks=parse_blocks(text); names={n for n,_ in blocks}
    missing=sorted(REQUIRED-names)
    out.mkdir(parents=True,exist_ok=True)
    if missing:
        raise SystemExit("Compilation refusée; blocs manquants: "+", ".join(missing))

    titles={
     "ATLAS_RUNTIME.md":"ATLAS Ω — RUNTIME 3.0",
     "ATLAS_EVAL.md":"ATLAS EVAL 3.0",
     "ATLAS_MAINTENANCE.md":"ATLAS MAINTENANCE 3.0",
     "ATLAS_SELF_MODEL.md":"ATLAS SELF MODEL 1.0"}
    view_coverage={}
    for filename,allowed in VIEWS.items():
        present=sorted(names & allowed)
        expected=sorted(allowed)
        miss=sorted(allowed-names)
        view_coverage[filename]={"expected":expected,"present":present,"missing":miss,
                                 "status":"PASS" if not miss else "FAIL"}
        (out/filename).write_text(render(titles[filename],src.name,blocks,allowed),encoding="utf-8")

    (out/"ATLAS_INSTRUCTIONS.atl").write_text(text,encoding="utf-8")
    chars=len(text)
    report={
      "source":src.name,
      "sha256":hashlib.sha256(text.encode()).hexdigest(),
      "blocks_found":sorted(names),"required":sorted(REQUIRED),"missing":missing,
      "instructions_characters":chars,"instructions_limit":7990,
      "instructions_limit_status":"PASS" if chars<=7990 else "FAIL",
      "views":view_coverage,
      "status":"PASS" if chars<=7990 and all(v["status"]=="PASS" for v in view_coverage.values()) else "FAIL"}
    (out/"coverage.json").write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    manifest={"authority":src.name,"generated":sorted([*VIEWS.keys(),"ATLAS_INSTRUCTIONS.atl","coverage.json"]),
              "status":report["status"]}
    (out/"manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding="utf-8")
    if report["status"]!="PASS": raise SystemExit("Validation FAIL")
    print(f"Compilation PASS — {chars} caractères")

def main():
    p=argparse.ArgumentParser()
    p.add_argument("source",nargs="?",default="atlas.atl")
    p.add_argument("-o","--out",default="generated")
    a=p.parse_args(); compile_views(Path(a.source),Path(a.out))
if __name__=="__main__": main()
