Conserver ici le corpus Atlas 2.7 comme archive de retour. La 3.0 est active seulement après mise à jour explicite du GPT.
