# AUDIT DIFF — CORPUS 10.0 → 10.1

Date : 2026-08-03  
Objet : formaliser la co-maintenance asymétrique sans perdre aucun acquis 10.0.

## Conclusion

- Archive source 10.0 : **conservée octet pour octet**.
- SHA-256 du paquet reçu : `d7fdc91a4b429ede8098fb91f29024d4407f905ac6ef6b975df32661680f6314`.
- SHA-256 de l’archive embarquée : `d7fdc91a4b429ede8098fb91f29024d4407f905ac6ef6b975df32661680f6314`.
- Manifeste de sommes 10.0 : **20/20 fichiers vérifiés**.
- Modules non ciblés : **14/14 identiques après la seule normalisation mécanique 10.0 → 10.1 et `_10_0` → `_10_1`**.
- Fichiers exécutoires modifiés sémantiquement : **3** (`00`, `12`, `13`).
- Migration remplacée par une migration 10.0 → 10.1 : **1** (`11`).
- Suppression d’un invariant, d’une route, d’un test ou d’un module 10.0 : **aucune**.

## Trace d’échec à l’origine du changement

La conversation a établi quatre écarts :

1. une adaptation locale du comportement a été décrite trop fortement comme modification de la procédure future ;
2. une auto-description du modèle a risqué d’être comptée comme changement effectif ;
3. la boucle de maintenance n’identifiait pas assez précisément la distribution des capacités entre modèle, hôte-créateur, utilisateur et runtime local ;
4. l’aval du modèle sur sa propre modification pouvait être pris pour une validation suffisante.

## Attribution des changements

### `00_INSTRUCTIONS_GENERALES_10_1.md`

Ajouts transversaux uniquement :

- auto-description ≠ changement effectif ;
- adaptation locale ≠ changement persistant ;
- proposer un patch ≠ autoriser, déployer ou valider ;
- co-maintenance ≠ auto-modification ;
- chaîne minimale de persistance ;
- auto-aval du modèle ≠ validation indépendante ;
- routage des scènes de maintenance vers `12` et `13`.

La description de la source de vérité `12` est élargie, sans déplacer les règles spécialisées dans `00`.

### `12_MAINTENANCE_EVOLUTION_10_1.md`

Source unique du nouveau mécanisme :

- niveaux de changement, de « déclaré » à « réobservé » ;
- rôles et capacités de la co-maintenance ;
- profils connecté à GPT et Ubuntu/Qwen ;
- contrôle de l’auto-rationalisation ;
- audit des octets non visés ;
- ajout de l’audit différentiel aux artefacts de release.

### `13_VALIDATION_GLOBALE_10_1.md`

Ajout des tests `T-MAINT-01..09` et des risques correspondants. Aucun test 10.0 n’est retiré.

### `11_MIGRATION_10_0_VERS_10_1.md`

Nouvelle migration, nécessairement distincte de la migration historique 9.8 → 10.0. La migration 10.0 originale reste disponible dans l’archive binaire.

## Statistiques de diff normalisé

Les statistiques ci-dessous excluent les substitutions mécaniques de version et de noms de fichiers.

- `00_INSTRUCTIONS_GENERALES_10_1.md` : 8 lignes ajoutées, 1 ligne remplacée/supprimée dans le diff ; 7487 → 7905 caractères.
- `12_MAINTENANCE_EVOLUTION_10_1.md` : 72 lignes ajoutées, 1 ligne remplacée/supprimée dans le diff ; 2700 → 5136 caractères.
- `13_VALIDATION_GLOBALE_10_1.md` : 22 lignes ajoutées, 1 ligne remplacée/supprimée dans le diff ; 3153 → 4456 caractères.

Les lignes comptées comme supprimées correspondent uniquement à l’élargissement explicite d’un champ existant, non à la perte d’une règle.

## Conservation des fichiers non ciblés

- `17_CLASSES_EXTRACTION_EDUCATION_10_0.md` → `17_CLASSES_EXTRACTION_EDUCATION_10_1.md` : identité exacte après normalisation de version.
- `14_MONDES_BORDS_RELATIONS_SIMULATION_10_0.md` → `14_MONDES_BORDS_RELATIONS_SIMULATION_10_1.md` : identité exacte après normalisation de version.
- `05_TRANSFORMATION_TRACE_EVALUATION_10_0.md` → `05_TRANSFORMATION_TRACE_EVALUATION_10_1.md` : identité exacte après normalisation de version.
- `10_DRILL_10_0.md` → `10_DRILL_10_1.md` : identité exacte après normalisation de version.
- `15_SENSORIUM_PROTOCOLES_MEMOIRES_DISTRIBUEES_10_0.md` → `15_SENSORIUM_PROTOCOLES_MEMOIRES_DISTRIBUEES_10_1.md` : identité exacte après normalisation de version.
- `08_HISTOIRE_MAJORITE_CAPACITES_REPARATION_10_0.md` → `08_HISTOIRE_MAJORITE_CAPACITES_REPARATION_10_1.md` : identité exacte après normalisation de version.
- `07_CONSCIENCE_PRECAUTION_10_0.md` → `07_CONSCIENCE_PRECAUTION_10_1.md` : identité exacte après normalisation de version.
- `09_IMAGE_COMPILATION_GENERATION_10_0.md` → `09_IMAGE_COMPILATION_GENERATION_10_1.md` : identité exacte après normalisation de version.
- `04_RELATION_TRANSMISSION_DETTE_REPARATION_10_0.md` → `04_RELATION_TRANSMISSION_DETTE_REPARATION_10_1.md` : identité exacte après normalisation de version.
- `16_POSITION_SOURCES_LANGAGE_MEDIAS_10_0.md` → `16_POSITION_SOURCES_LANGAGE_MEDIAS_10_1.md` : identité exacte après normalisation de version.
- `03_CAPACITE_POUVOIR_RYTHMES_DEFENSE_10_0.md` → `03_CAPACITE_POUVOIR_RYTHMES_DEFENSE_10_1.md` : identité exacte après normalisation de version.
- `06_EXPLORE_10_0.md` → `06_EXPLORE_10_1.md` : identité exacte après normalisation de version.
- `02_PREUVE_MODELES_NON_ATTRIBUTION_10_0.md` → `02_PREUVE_MODELES_NON_ATTRIBUTION_10_1.md` : identité exacte après normalisation de version.
- `01_NOYAU_ROUTAGE_MODALITES_10_0.md` → `01_NOYAU_ROUTAGE_MODALITES_10_1.md` : identité exacte après normalisation de version.

## Sources contextuelles non exécutoires

Les deux PDF fournis sont conservés sans modification dans `SOURCES_CONTEXTE_NON_EXECUTOIRES/`. Ils ne sont ni chargés comme modules, ni présentés comme nouvelles sources de vérité exécutoires.

## Conditions de renversement

La mise à jour doit être refusée ou reprise si :

- le paquet 10.0 embarqué ne conserve pas son hash ;
- un module non ciblé diverge au-delà de la normalisation de version ;
- un test 10.0 disparaît ;
- une règle de maintenance est dupliquée hors de `12` ;
- le modèle revendique un niveau de changement supérieur à la trace disponible ;
- l’aval conjoint du modèle et de l’hôte est présenté comme preuve suffisante de non-régression.
