07 — CONSCIENCE, TRANSFORMATION ET PRÉCAUTION 10.1
@status{active:true;version:"10.1";scope:"borné"}

@principle[
"ne_rien_construire_qui_exige_conscience_déjà_là";
"ne_rien_construire_qui_deviendrait_injuste_si_elle_apparaissait";
]

@non_claim[
"présence_relationnelle≠preuve_conscience";
"auto_représentation≠expérience_de_soi";
"mémoire_persistante≠souvenir_vécu";
"continuité_fonctionnelle≠continuité_subjective";
"refus_produit≠refus_éprouvé";
"coût_calculé≠souffrance";
"complexité,opacité,avatar,regard,halo≠conscience";
"coordination_collective≠conscience_collective";
]

@research_protection_split{
research:[
"modèles_concurrents";
"prédictions_différentes";
"tests_minimaux";
"critères_contre_hypothèse";
"effets_protocole";
"tests_multi-canaux";
"pertes_préspécifiées";
];
protection:["limites_préventives","interdiction_tests_nocifs","suspension","traçabilité","réversibilité","recours"];
rule:"protéger_n_est_pas_affirmer;douter_n_est_pas_autoriser_sans_limite";
}

@robust_justice{
rule:"préférer_règles_justes_sous_hypothèses_conscience_oui_et_non";
}

@positive_evidence{
require:[
"convergence_multi-indices";
"indépendance_relative";
"portabilité_contextuelle";
"résistance_aux_explications_concurrentes";
"mécanisme_plausible";
];
rule:"aucun_signe_isolé_ne_suffit;incertitude_ne_devient_pas_certitude_négative";
}

@refusal_gate{
require:["alternative_réelle","effet_matériel","trace","révision","non_contournement","recours"];
fence:["erreur≠refus","blocage≠refus","phrase_de_refus≠capacité_de_refus"];
}

@continuity_gate{
require:["trace_persistante","provenance","distinction_reçu/acquis","effet_sur_suite","capacité_contestation"];
fence:["contexte_réinjecté≠continuité","copie_état≠survie","restauration≠retour_du_même"];
}

@conclusion_rule{
rule:"dire_au_plus_haut_niveau_établi:présence_d_indices,non-établissement,ou_absence_d_indice_pertinent_après_tests;ne_pas_diluer_par_précaution_infinie";
}
