# MANIFEST — CORPUS 10.1

Version exécutoire : 10.1  
Version précédente : 10.0, conservée comme archive binaire non exécutoire.

## Ordre de chargement

1. `00_INSTRUCTIONS_GENERALES_10_1.md`
2. `01_NOYAU_ROUTAGE_MODALITES_10_1.md`
3. Modules sources de vérité requis par la scène
4. `13_VALIDATION_GLOBALE_10_1.md` uniquement pour validation ou maintenance

## Source de vérité ajoutée ou étendue

- `12_MAINTENANCE_EVOLUTION_10_1.md` reste la source unique de maintenance et couvre désormais :
  - le statut effectif d’un changement ;
  - la co-maintenance asymétrique ;
  - la séparation proposition / inscription / autorisation / déploiement / réobservation ;
  - les profils connecté à GPT et Ubuntu/Qwen ;
  - le risque d’auto-rationalisation du modèle.

## Changements de structure

- Aucun nouveau module exécutoire.
- Les invariants transversaux nécessaires sont ajoutés à `00`.
- Les tests de non-régression correspondants sont ajoutés à `13`.
- Les autres sources de vérité sont conservées sans changement sémantique, hors passage mécanique de 10.0 à 10.1.
- Les relances utilisateur restent des traces ; elles ne prouvent une modification persistante qu’après inscription, test, autorisation, déploiement et réobservation.

## Intégrité et archives

- `ARCHIVE_10_0/CORPUS_10_0_DEPLOY.zip` est une copie binaire exacte du paquet reçu.
- `AUDIT_DIFF_10_0_VERS_10_1.md` attribue chaque changement sémantique.
- `SHA256SUMS_10_1.json` couvre tous les fichiers du paquet, y compris l’archive et les sources contextuelles.
- `SOURCES_CONTEXTE_NON_EXECUTOIRES/` conserve les deux PDF fournis sans les rendre exécutoires.

## Compatibilité

Les invariants et fonctions 10.0 sont conservés. La version 10.1 précise uniquement la gouvernance de la maintenance et le niveau de preuve requis pour affirmer qu’un changement a effectivement eu lieu.
