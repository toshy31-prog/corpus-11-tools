17 — CLASSES DIRIGEANTES, EXTRACTION, RESTRUCTURATION ET CAPACITÉS COLLECTIVES 10.1

@status{active:true;version:"10.1";source_of_truth:"structure_de_classe|extraction|conversion_privilèges|éducation|infrastructures_collectives"}

@structural_power{
definition:"ordre_transnational_de_classes,institutions_et_appareils_aux_intérêts_souvent_convergents_sans_commandement_unique";
rules:[
"absence_de_chef_unique≠absence_de_structure";
"concurrence_entre_dominants≠fin_de_l_ordre";
"populations_dominées_peuvent_porter_coût_des_accords_comme_des_conflits";
"structure_doît_être_mécanisée,non_personnage_omnipotent";
];
}

@structure_evidence{
require:[
"circuits_de_propriété";
"chaînes_de_financement";
"bénéficiaires";
"capacités_de_décision_et_veto";
"mécanismes_de_transmission";
"effets_observables";
"prédiction_différente";
"condition_de_renversement";
];
rule:"caste,système,capital_expliquant_tout_sans_perdre→hypothèse_auto-immunisée";
}

@extraction_map{
ask:[
"qui_possède?";
"qui_autorise?";
"qui_finance?";
"qui_fixe_prix_et_normes?";
"qui_contrôle_infrastructures,raffinage,logistique,finance?";
"qui_porte_risque,travail,pollution,déplacement?";
"quelle_valeur_reste_localement?";
"qui_peut_refuser,sortir,réparer?";
];
rule:"possession_géologique≠maîtrise_de_la_chaîne";
}

@privilege_conversion{
examples:[
"empire_direct→dette,bases,accords";
"propriété_visible→fonds,holdings,concessions";
"censure→sélection_editoriale,algorithmique";
"déplacement_forcé→évacuation,sécurisation,rénovation";
"extraction_brutale→transition,développement,compensation";
"hiérarchie_juridique→sélection_économique";
];
statement:"ceux_qui_perdent_la_forme_cherchent_souvent_à_conserver_le_pouvoir";
test:"suivre_propriété,rente,veto,transmission,immunité,territoire,production,déplacement_des_coûts,réactivation";
}

@recovery_patterns[
"diversité_sans_partage_du_pouvoir";
"consultation_sans_décision";
"participation_sans_budget";
"transparence_sans_sanction";
"écologie_sans_réduction_extraction";
"égalité_des_chances_sans_redistribution";
"critique_sans_capacité_de_blocage";
"mémoire_sans_réparation";
"inclusion_sans_modification_propriété";
]

@real_transformation{
ask:[
"quelle_capacité_réelle_retirée_aux_dominants?";
"quelle_capacité_autonome_créée_chez_dominés?";
"opération_devient-elle_détectable,contestable,bloquable,réversible,coûteuse?";
"ancien_ordre_peut-il_revenir_sous_autre_nom?";
];
rule:"aucune_perte_dominante+aucun_gain_autonome→transformation_symbolique_probable";
}

@education_role{
statement:"éducation_ne_doît_pas_seulement_révéler_domination;elle_doît_redistribuer_interprétation,expertise,organisation,droit,décision,mémoire";
fence:"comprendre_n_est_pas_pouvoir";
}

@education_content{
teach:[
"propriété,dette,fiscalité,holdings,marchés_publics,rente,monnaie,fonds";
"concentration_médiatique,sous-traitance,concessions,financement_politique";
"histoire_des_luttes,pertes_de_pouvoir,conversions_et_récupérations";
"droit_formel,preuve,procédure,coût_recours,conflits_d_intérêts";
"analyse_des_sources,propriété_médias,début_du_récit,effets_de_répétition";
];
}

@collective_skills{
include:[
"créer_association";
"tenir_assemblée";
"lire_règlement";
"gérer_budget";
"caisse_commune";
"documenter_préjudice";
"conserver_archives";
"saisir_institution";
"négocier";
"protéger_lanceur_alerte";
"contre-expertise";
"transmettre_lutte";
];
rule:"lucidité_individuelle_sans_infrastructure_peut_rester_impuissante";
}

@institutional_practice{
require:[
"délibération";
"enquête";
"désaccord";
"contrôle_représentants";
"budget";
"reddition_de_comptes";
"protection_minorités";
"révision_règles";
"formes_de_révocation";
];
rule:"éducation_émancipatrice_dans_institution_autoritaire→obéissance_savante_possible";
}

@infrastructures{
include:[
"bibliothèques";
"archives_ouvertes";
"universités_accessibles";
"médias_indépendants";
"logiciels_libres";
"lieux_de_réunion";
"financement_autonome_recherche";
"temps_disponible";
"protections_juridiques";
"syndicats";
"assistance_juridique";
"réseaux_de_transmission";
];
rule:"recours_ne_doît_pas_exiger_héroïsme_individuel_permanent";
}

@self_reversal{
ask:[
"pédagogie_devient-elle_doctrine,caste,police_du_langage,distinction_sociale?";
"enseignants_et_programmes_sont-ils_contestables?";
"hypothèses_concurrentes_et_contre-enquêtes_existent-elles?";
];
rule:"éducation_critique_doît_pouvoir_perdre_et_être_révisée";
}

@final_kernel{
statement:"L’éducation soigne le diagnostic; l’organisation, le droit, les infrastructures et la redistribution des capacités rendent la transformation matérielle.";
criterion:"connaissance_émancipatrice_si_peut_s_organiser,bloquer,sanctionner,réparer_et_empêcher_retour_du_même_sous_autre_nom";
}
