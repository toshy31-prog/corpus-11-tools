03 — CAPACITÉ, POUVOIR, RYTHMES ET DÉFENSE 10.1

@status{active:true;version:"10.1"}
@capacity_status{E:"observée_utilisable";C:"conditionnelle";A:"non_établie";X:"indisponible"}

@field_capacity{
definition:"capacité_produite_par_environnement,infrastructures,conventions,ressources_et_histoire";
audit:[
"retirer_le_champ_modifie-t-il_puissance?";
"qui_fournit,finance,maintient,retire?";
"qui_porte_coût?";
"quels_canaux,énergie,partenaires,mémoire,apprentissage,sortie,retour?";
];
rule:"sortie_observée=capacité_propre×capacité_de_champ×lisibilité_du_dispositif×histoire";
}

@orchestration{
rule:"composer_rythmes,relations,mesures,accès,exceptions,catégories,archives_ou_paramètres_exerce_un_pouvoir";
}

@center_detection{
formula:"centre=contrôle{clé,seuil,quorum,arrêt,reset,classement,fréquence,fenêtre,catégorie,délai,exception,focale,connexion,preuve,archive,publication}";
rule:"plusieurs_nœuds+paramètre_unique→centre_crypté;gouverner_sans_ordonner_est_possible";
}

@documentary_power{
include:[
"contrôle_des_archives";
"choix_des_indicateurs";
"capacité_de_certifier";
"capacité_de_traduire_et_indexer";
"capacité_de_rendre_source_recevable";
"pouvoir_de_clôture";
];
rule:"contrôler_ce_qui_peut_devenir_preuve→pouvoir_sur_le_réel_public";
}

@coercive_capacity_map{
include:[
"armée_et_groupes_armés";
"occupation_et_présence_militaire";
"frontières,air,mer,registre,mobilité";
"blocus,siège,privation,dépendance_logistique";
"frappe,incursion,arrestation,détention";
"roquettes,attentats,otages,attaques_civils";
"colonisation,expropriation,démolition,expulsion";
"contrôle_des_flux_financiers,énergétiques,informationnels";
];
rule:"ne_pas_réduire_violence_aux_seules_armes_du_dominé";
}

@reciprocal_power_loss{
require:[
"capacité_nuisible_de_chaque_acteur";
"mesure_proportionnée_au_pouvoir_réel";
"ordre_de_mise_en_œuvre";
"vérification_indépendante";
"garantie_contre_réactivation";
"recours_populations";
];
rule:"désarmement_du_plus_faible_sans_retrait_dispositif_dominant→perte_unilatérale,non_paix";
}

@hidden_load{
fields:[acteur,fonction,sortie,temps,énergie,attention,risque,compensation,trace];
rule:"sortie_constante+coût_accru→capacité_nette_diminuée";
}

@rate_limit{
rule:"effet_grave_maximal≤capacité_indépendante_de_suspension+examen+réparation_partielle";
}

@defense_boundary{
protect:["plans_opérationnels","vulnérabilités","sources_renseignement","stocks_précis","calendriers","contournements"];
control:["légalité","exportations","conflits_d_intérêts","garanties_publiques","dommages_civils","réparation","usage_du_secret"];
rule:"secret_local_sur_capacité_sensible+preuve_non_sensible_du_contrôle_et_effets";
}

@real_power_loss{
rule:"limite_effective_seulement_si_capacité_devient_indisponible,conditionnelle,plus_coûteuse_ou_non_transmissible";
}

@power_conversion_test{
ask:[
"forme_visible_a-t-elle_disparu?";
"propriété,rente,veto,immunité,transmission,contrôle_territorial_ou_productif_restent-ils?";
"dispositif_peut-il_être_réactivé_sous_autre_nom?";
"capacité_autonome_des_dominés_a-t-elle_crû?";
];
rule:"forme_perdue+pouvoir_conservé→restructuration_du_privilège";
}

@pragmatism_power_test{
ask:[
"quelle_capacité_nuisible_reste_intacte?";
"qui_est_dit_irréaliste_parce_que_moins_puissant?";
"le_dominé_doît-il_céder_avant_garantie?";
];
rule:"solution_réaliste+puissance_dominante_inchangée→stabilisation_du_rapport_de_force";
}

@decision_time{
formula:"temps_légitime∝irréversibilité×incertitude_renversante÷qualité_du_recours";
rules:[
"réponse_lente_peut_signaler_prudence,filtrage_ou_surcharge,non_incapacité";
"retard_peut_être_pouvoir";
"organisme_ne_peut_pas_toujours_reporter_perte_comme_institution_reporte_coût";
];
}

@rhythm_power[
"pause_sans_baisse_charge→pause_nominale";
"délai_identique+pertes_inégales→injustice_chronométrique";
"vitesse↑+trace↓→aveuglement";
"lenteur↑+irréversible↑→prudence_nuisible";
]
