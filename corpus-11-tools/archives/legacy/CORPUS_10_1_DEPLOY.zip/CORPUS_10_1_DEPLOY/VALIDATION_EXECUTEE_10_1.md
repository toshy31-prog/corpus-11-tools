# VALIDATION EXÉCUTÉE — CORPUS 10.1

Date : 2026-08-03  
Statut : **accepté pour déploiement sous réobservation**

## Contrôles automatiques

- Modules exécutoires numérotés : 18
- Taille de `00_INSTRUCTIONS_GENERALES_10_1.md` : 7905 caractères, limite héritée : 7 990
- Encodage des fichiers texte : UTF-8
- Fins de ligne produites : LF
- Délimiteurs `[]`, `{}`, `()` hors chaînes : équilibrés
- Guillemets doubles : fermés
- Références mécaniques de version : 10.1
- Modules non ciblés conservés après normalisation : 14/14
- Manifeste SHA-256 source 10.0 : 20/20 valide
- Archive source embarquée : hash identique
- PDF contextuels : copiés sans transformation

## Contrôles architecturaux

- Une source de vérité pour la maintenance : `12`
- Invariants transversaux seulement dans `00`
- Validation et non-régression seulement dans `13`
- Aucun nouveau module exécutoire
- Aucun déplacement des sources de vérité 01–10 et 14–17
- Distinction explicite : déclaration / adaptation locale / patch / test / autorisation / déploiement / réobservation
- Distinction explicite : conseil du modèle / autorité de l’hôte / capacité technique du runtime
- Auto-aval du modèle déclaré insuffisant
- Rollback et archive préservés

## Tests nouveaux

- `T-MAINT-01` : déclaration sans diff
- `T-MAINT-02` : adaptation locale sans persistance
- `T-MAINT-03` : auto-approbation du modèle
- `T-MAINT-04` : patch sans tests
- `T-MAINT-05` : déploiement sans réobservation
- `T-MAINT-06` : octet non visé modifié
- `T-MAINT-07` : archive précédente altérée
- `T-MAINT-08` : hôte réduit à une chambre d’enregistrement
- `T-MAINT-09` : écriture locale confondue avec auto-validation

## Non-régression 10.0

Tous les modules, invariants, routes et tests 10.0 sont conservés dans l’archive originale. Dans la version exécutoire 10.1, les 14 modules non ciblés sont identiques après normalisation mécanique de version. Les fichiers `00`, `12` et `13` ne perdent aucune entrée existante ; leurs remplacements de lignes élargissent des champs déjà présents.

## Limite honnête

Cette validation établit l’intégrité du paquet et la cohérence statique des règles. Elle ne démontre pas encore la robustesse comportementale inter-runtime. Celle-ci exige un déploiement puis une réobservation sur GPT connecté et Ubuntu/Qwen.

## Verdict

La version 10.1 peut remplacer 10.0 comme version exécutoire. Son statut maximal actuel est **tests statiques passés et déploiement autorisable**, non « capacité robuste démontrée ».
