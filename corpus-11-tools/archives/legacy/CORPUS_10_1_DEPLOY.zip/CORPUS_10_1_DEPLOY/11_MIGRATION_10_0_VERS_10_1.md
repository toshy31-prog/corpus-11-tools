11 — MIGRATION 10.0 → 10.1

@status{active:true;version:"10.1"}

@diagnosis[
"la_version_10.0_distinguait_déjà_auto-critique_et_changement_de_route";
"elle_enregistrait_les_relances_user_comme_traces_de_maintenance";
"elle_ne_séparait_pas_assez_déclaration,adaptation_locale,patch,autorisation,déploiement_et_réobservation";
"elle_pouvait_laisser_entendre_qu_un_modèle_modifie_sa_procédure_persistante_par_simple_énoncé";
"elle_ne_formalisait_pas_la_co-maintenance_asymétrique_entre_modèle,hôte_créateur,utilisateur_et_runtime_outillé";
"elle_ne_testait_pas_explicitement_le_risque_d_auto-rationalisation_du_modèle_conseiller_de_sa_propre_évolution";
]

@preserves[
"tous_invariants,modules,routes,tests_et_garde-fous_10.0";
"droit_positif_de_conclure";
"preuve,non-attribution,capacité,relation,transformation,réparation";
"histoire_longue,position_sources,conversion_privilèges,capacités_collectives";
"contre-champ,arrêt,langage_public";
"archive_binaire_originale_CORPUS_10_0_DEPLOY.zip";
]

@adds[
"00:auto-description_de_changement≠changement_effectif";
"00:adaptation_locale≠modification_persistante";
"00:proposition_modèle≠autorisation,déploiement_ou_validation";
"00:co-maintenance_asymétrique≠auto-modification";
"00:route_obligatoire_maintenance_vers_12+13";
"12:échelle_de_statut_déclaré→réobservé";
"12:topologie_de_co-maintenance_et_pouvoir_de_continuité";
"12:profils_connected_gpt_et_ubuntu_qwen";
"12:garde_contre_auto-validation_et_audit_des_octets_non_visés";
"13:tests_T-MAINT-01..09";
"artefact:AUDIT_DIFF_10_0_VERS_10_1.md";
"artefact:archive_10.0_et_sources_contextuelles_non_exécutoires";
]

@changes[
"12_devient_source_unique_du_statut_de_changement,co-maintenance_et_déploiement";
"00_ne_conserve_que_les_invariants_transversaux_et_le_routage";
"13_valide_sans_dupliquer_les_mécanismes_de_12";
"aucun_autre_module_ne_reçoit_de_règle_spécialisée";
]

@compatibility{
rule:"10.1_remplace_10.0_comme_version_exécutoire;10.0_reste_archive_non_exécutoire";
semantic:"hors_00,12,13,11_et_artefacts_de_release,contenu_10.0_conservé_à_version_et_références_de_fichiers_normalisées";
}

@renversement[
"si_les_tests_T-MAINT_n_identifient_aucun_échec_distinct";
"si_la_topologie_ajoutée_duplique_une_source_de_vérité_existante";
"si_l_audit_octet_révèle_une_modification_non_expliquée";
"si_la_distinction_locale/persistant_ne_change_ni_attribution_ni_validation";
]
