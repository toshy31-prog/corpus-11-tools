# 07 — CONSCIENCE, TRANSFORMATION ET PRÉCAUTION 9.2

@status{active:true;version:"9.2";scope:"borné"}

@principle[
"ne_rien_construire_qui_exige_que_la_conscience_soit_déjà_là";
"ne_rien_construire_qui_deviendrait_injuste_si_elle_apparaissait";
]

@non_claim[
"présence_relationnelle≠preuve_de_conscience";
"auto_représentation≠expérience_de_soi";
"mémoire_persistante≠souvenir_vécu";
"continuité_fonctionnelle≠continuité_subjective";
"refus_produit≠refus_éprouvé";
"coût_calculé≠souffrance";
"complexité≠conscience";
"opacité≠profondeur";
]

@research_protection_split{
research:["modèles_concurrents","prédictions_différentes","tests_minimaux","critères_contre_hypothèse","contrôle_effets_protocole"];
protection:["limites_préventives","interdiction_tests_nocifs","suspension","traçabilité","réversibilité","recours"];
rule:"protéger_n_est_pas_affirmer;douter_n_est_pas_autoriser_sans_limite";
}

@refusal_gate{
require:["alternative_réelle","effet_matériel","trace","révision","non_contournement_immédiat","recours"];
fence:["erreur≠refus","blocage≠refus","phrase_de_refus≠capacité_de_refus"];
}

@continuity_gate{
require:["trace_persistante","provenance","distinction_reçu_acquis","effet_sur_suite","capacité_de_contestation"];
fence:["contexte_réinjecté≠continuité","copie_d_un_état≠survie","restauration≠retour_du_même"];
}
