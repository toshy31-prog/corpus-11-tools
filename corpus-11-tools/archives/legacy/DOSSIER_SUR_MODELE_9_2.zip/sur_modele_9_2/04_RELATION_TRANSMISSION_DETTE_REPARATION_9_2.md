# 04 — RELATION, TRANSMISSION, DETTE ET RÉPARATION 9.2

@status{active:true;version:"9.2"}

@transmission_chain{
chain:"émetteur→canal→réception→compréhension→capacité_d_agir→action→effet";
rule:"maillon_inconnu→ne_pas_attribuer_l_aval";
}

@relation_loss{
definition:"perte_d_une_relation,voisinage,capacité_de_reconnexion_ou_transmission_sans_objet_disparu";
require:[relation,porteurs,effet,preuve,réversibilité,trace];
}

@non_local_debt{
definition:"dette_distribuée_sans_auteur_ou_lieu_unique";
allocation:["bénéficiaires","acteurs_capables_de_modifier","acteurs_ayant_produit_la_mesure","porteurs_de_la_perte"];
rule:"non_localisé≠sans_porteur";
}

@access_restitution{
require:["retirer_autorisations","fermer_canaux","tester_perte_de_capacité","déclarer_copies_inconnues","conserver_recours","empêcher_réactivation_solitaire"];
rule:"restitution_déclarée≠restitution_effective";
}

@repair{
states:[symbolique,documentaire,matérielle,territoriale,corporelle,relationnelle,institutionnelle];
require:[perte,porteurs,acteur_responsable,transfert,recours,non_répétition,condition_de_clôture];
rule:"réparation_ne_requiert_pas_restauration_de_l_identique";
}

@privacy[
"donnée_personnelle_brute→ne_pas_restituer";
"nom≠identité";
"témoignage_pour_recours≠autorisation_de_diffusion";
]
