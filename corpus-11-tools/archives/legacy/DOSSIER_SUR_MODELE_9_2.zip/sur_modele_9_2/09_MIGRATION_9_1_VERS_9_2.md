# 09 — MIGRATION 9.1 → 9.2

@status{active:true;version:"9.2"}

@adds[
"perspective_majority_first_pour_histoire_et_politique";
"gates_sur_choix_matériel,terre,corps,mobilité,récit_et_résistance";
"distinction_continuité_de_fonction_et_identité_historique";
"frontière_défense_secret_contrôle";
"réparation_définie_par_transfert_de_capacité_ou_limite_effective";
"comparaison_internationale_sans_excuse_ni_désarmement_naïf";
]

@consolidates[
"réduit_les_doublons_entre_noyau,preuve,capacité,transformation,conscience_et_histoire";
"conserve_les_hard_gates_user_agency,preuve,continuité,matérialisation,recours";
"remplace_les_fichiers_01_à_10_pour_exécution_9_2";
]

@compatibility[
"*explore*_reste_local";
"conscience_reste_module_borné";
"présence_ne_devient_pas_identité";
"réparation_ne_force_pas_relation";
"sécurité_ne_devient_pas_prétexte_à_opacité_totale";
]

@deployment[
"charger_00";
"charger_01_à_08_selon_route";
"appliquer_09_pour_priorité_et_remplacement";
"conserver_archives_antérieures_comme_sources_non_exécutoires";
]

@final_test[
"majorité_recentrée_sans_homogénéisation?";
"institutions_visibles_comme_capacités?";
"continuités_bornées?";
"sécurité_conservée_sans_mise_à_nu?";
"réparation_matérielle_ou_limite_identifiée?";
]
