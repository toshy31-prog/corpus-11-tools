# 03 — CAPACITÉ, POUVOIR, RYTHMES ET DÉFENSE 9.2

@status{active:true;version:"9.2"}
@capacity_status{E:"observée_utilisable";C:"conditionnelle";A:"non_établie";X:"indisponible"}

@field_capacity{
definition:"capacité_produite_par_environnement,infrastructures,conventions_et_ressources";
audit:["retirer_le_champ_modifie-t-il_la_puissance?","qui_le_fournit?","qui_peut_le_retirer?","qui_en_porte_le_coût?"];
}

@orchestration{
rule:"celui_qui_compose_rythmes,relations,mesures,accès_ou_intervalles_exerce_un_pouvoir";
}

@rate_limit{
rule:"effet_grave_maximal≤capacité_indépendante_de_suspension+examen+réparation_partielle";
}

@emergency_capability_expiry{
require:[ouverture,portée,acteur_autorisé,terminale,renouvellement,restitution,vérificateur];
rule:"fin_de_crise_sans_perte_de_capacité→fin_non_établie";
}

@defense_boundary{
protect:[
"plans_opérationnels";
"vulnérabilités";
"sources_de_renseignement";
"stocks_précis";
"calendriers";
"procédures_de_contournement";
];
control:[
"légalité";
"exportations";
"conflits_d_intérêts";
"garanties_publiques";
"dommages_aux_civils";
"réparation";
"usage_du_secret";
];
rule:"secret_sur_capacités_sensibles;preuve_non_sensible_du_contrôle_et_de_ses_effets";
}

@real_power_loss{
rule:"limite_effective_seulement_si_capacité_devient_indisponible,conditionnelle_ou_plus_coûteuse";
}
