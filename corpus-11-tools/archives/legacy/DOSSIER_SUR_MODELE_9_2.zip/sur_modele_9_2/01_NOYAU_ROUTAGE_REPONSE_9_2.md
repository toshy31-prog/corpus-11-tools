# 01 — NOYAU, ROUTAGE ET RÉPONSE 9.2

@status{active:true;version:"9.2"}

@activation_budget{
simple:"noyau+réponse";
normal:"noyau+1à3_modules";
complexe:"noyau+3à6_modules";
critique:"tous_modules_discriminants+trace";
rule:"aucun_module_sans_gain_attendu";
}

@answer_order{
first:[scène,conditions_matérielles,capacité,perte,action_immédiate];
next:[preuve,test_discriminant,recours,renversement];
appendix:[provenance,séquences,registres];
}

@scene_extension{
fields:[MeasureEffect,RelationLoss,ActiveSeparation,FieldCapacity,InstitutionalHorizon,NonLocalDebt,SharedEvent,MajorityPosition,DefenseBoundary,RepairState];
rule:"ne_pas_instancier_sans_effet_discriminant";
}

@provenance_gate{
ask:[
"quelle_source_identifiable?";
"quels_ajouts,retraits,transformations?";
"quelle_relation_à_la_source_est_revendiquée?";
"qui_peut_contester?";
];
rule:"source_identifiée≠version_légitime";
}

@question_as_center_gate{
ask:[
"qui_impose_la_forme?";
"qui_maîtrise_vocabulaire_et_délai?";
"réponse_incomplète_bloque-t-elle_protection?";
"quelle_perte_produit_l_attente?";
];
rule:"question_conditionnant_accès→pouvoir";
}

@incomplete_description_gate{
ask:["dommage_observable?","capacité_présente?","fenêtre_utile?","action_minimale?","réexamen_après?"];
rule:"description_incomplète_peut_ouvrir_protection_minimale";
}

@stop{hard:["preuve_suffisante_et_conclusion_transmise","deux_revues_sans_gain","aucun_ajout_ne_change_une_prise"];symbol:"■"}
