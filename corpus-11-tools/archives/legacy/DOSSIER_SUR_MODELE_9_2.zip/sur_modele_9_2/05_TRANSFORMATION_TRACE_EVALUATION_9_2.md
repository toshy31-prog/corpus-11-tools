# 05 — TRANSFORMATION, TRACE ET ÉVALUATION 9.2

@status{active:true;version:"9.2"}

@operations{
Mig:"déplacer_fonctionnellement";
Split:"séparer_objet_surchargé";
Retire:"retirer_après_transfert";
Endogenize:"marquer_données_produites";
Deorchestrate:"retirer_maîtrise_exclusive";
TerminalLink:"lier_temporairement";
RateBind:"lier_portée_et_recours";
ConclusionFence:"bloquer_réemploi";
RhythmSplit:"séparer_temporalités";
MeasurementWindow:"ouvrir_mesure_limitée";
FieldUnbind:"tester_puissance_sans_champ";
AuthorityReset:"ramener_autorité_initiale_à_zéro";
AccessRestitutionTest:"vérifier_perte_effective_des_accès";
MajorityRecenter:"réordonner_depuis_conditions_matérielles_de_la_majorité";
BurdenTrace:"suivre_qui_porte_travail,risque,violence,épuisement_et_perte";
BenefitTrace:"suivre_qui_reçoit_profit,terre,capital,prestige_et_sécurité";
AlternativeAudit:"tester_options_accessibles,sûres,finançables_et_réversibles";
BodySovereignty:"tester_consentement,intégrité,soin,reproduction_et_refus";
MobilityChoice:"distinguer_partir,être_orienté,déplacé,exilé_ou_empêché_de_rester";
LandPower:"suivre_propriété,usage,transmission,expropriation_et_restitution";
NarrativeCapture:"identifier_qui_nomme,archive,classe,expose_et_représente";
ResistanceRestore:"réintégrer_actions,savoirs_et_solidarités_des_dominés";
CaptureAudit:"chercher_filtrage,retard,dépendance,conflit_d_intérêts_et_contournement";
ExternalizationTrace:"relier_bénéfices_centraux_et_dommages_éloignés";
ColonialContinuity:"tester_fonctions_persistantes_sans_identité_totale";
RepairMaterialize:"convertir_reconnaissance_en_transfert_ou_limite";
PowerLossTest:"vérifier_perte_réelle_de_capacité_nuisible";
DefenseBoundary:"séparer_protection_légitime,secret_nécessaire_et_faute_cachée";
PeerComparison:"comparer_sans_excuse_ni_désarmement_naïf";
}

@decision_trace{
fields:[conclusion,preuve,conditions,limites,capacité,majorité,perte,bénéfice,continuité,réparation,recours,renversement];
}

@hard_fail[
"limite_sans_perte_observable_de_puissance";
"reconstruction_présentée_comme_résurrection";
"ancienne_autorité_transmise_par_similitude";
"restitution_sans_test";
"intervention_partielle_présentée_comme_victoire_totale_ou_nullité";
"reconnaissance_présentée_comme_réparation";
"continuité_de_fonction_présentée_comme_conspiration_continue";
"transparence_totale_présentée_comme_contrôle_sûr";
]
