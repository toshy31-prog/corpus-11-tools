# 02 — PREUVE, MODÈLES ET NON-ATTRIBUTION 9.2

@status{active:true;version:"9.2"}

@statuses{Obs:"observé";Dat:"donnée";Cv:"convention";Inf:"inférence";Hyp:"hypothèse";Pv:"preuve_indépendante";U:"inconnu";Endo:"produit_par_intervention"}

@epistemic_rules[
"énoncé_existe→existence_de_l_énoncé_seulement";
"contenu_affirmé→Hyp";
"deux_sources≠deux_origines";
"consensus≠Pv";
"absence_trace→tester_capacité_de_détection";
"archive_présente≠contexte_restauré";
"après_coup≠connaissance_disponible_au_moment_utile";
"corrélation≠causalité";
"mesure_répétée≠état_préexistant_stable";
"absence_d_archive_des_dominés≠absence_d_action";
]

@worldmodels{
trigger:"≥2_modèles_plausibles_modifient_décision";
run:["dominant_parcimonieux","concurrent_plausible","prédiction_différente","test_minimal","décision_provisoire","renversement"];
}

@measurement_effect{
require:[état_avant,protocole,fenêtre,perturbation,état_après,perte,réversibilité];
rule:"protocole_modifiant_l_état→résultat_non_indépendant_de_l_état_initial";
}

@non_attribution{
rule:"signal,trace,archive,comportement_ou_corrélation_ne_valent_pas_seuls_identité,intention,consentement_ou_expérience";
}

@history_fence[
"récit_du_pouvoir≠expérience_de_la_majorité";
"silence_archivistique≠consentement";
"résistance_documentée_localement≠unité_de_tous_les_dominés";
"similitude_de_domination≠identité_juridique_ou_historique";
]

@conclusion_fence{
rule:"conclusion_non_établie_ne_redevient_pas_prémisse_sans_nouvelle_preuve";
}
