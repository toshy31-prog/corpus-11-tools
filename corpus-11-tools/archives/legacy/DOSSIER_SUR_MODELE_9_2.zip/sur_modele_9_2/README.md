# DOSSIER SUR-MODÈLE 9.2

Version consolidée remplaçant les fichiers exécutoires 8.8–9.1.

- Instructions générales : 7948 caractères.
- 00 : contraintes globales.
- 01–08 : modules exécutoires.
- 09 : migration et ordre de chargement.
- Les versions antérieures restent des archives de provenance non exécutoires.

Ordre : charger 00, puis 01–08 selon la route, puis appliquer 09.
