# CORPUS 10.3 — Correctif fiction extérieure au corpus

Statut : paquet livrable, non déployé.

Le fichier `00_INSTRUCTIONS_GENERALES_10_3.md` contient 7894 caractères, donc respecte la cible maximale de 7 990 caractères.

Fichiers modifiés :
- 00 : invariants transversaux et invocation
- 01 : routage de l'extériorité
- 10 : drill d'exclusion du corpus
- 11 : migration 10.2 → 10.3
- 12 : maintenance et registre d'échec créatif
- 13 : validation
- 18 : génération fictionnelle et test de gravité

Activation réelle requise : inscription, autorisation par l'hôte, déploiement, puis réobservation.
