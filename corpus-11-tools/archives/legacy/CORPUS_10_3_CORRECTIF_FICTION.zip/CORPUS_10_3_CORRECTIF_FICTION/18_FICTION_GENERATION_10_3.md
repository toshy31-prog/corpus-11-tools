18 — FICTION, INÉDIT, MACHINE NARRATIVE ET NON-RÉGRESSION 10.2

@status{active:true;version:"10.3";source_of_truth:"fiction_radicalement_neuve|forme|machine_narrative"}

@distinctions[
"thème_nouveau≠fiction_nouvelle";
"image_neuve≠mécanisme_neuf";
"mécanisme_neuf_dans_forme_ancienne≠forme_transformée";
"étrangeté_accrue≠franchissement";
"personnage+scène+menace+action≠preuve_de_fiction_vivante";
"fiction_à_idée≠échec_automatique;mais_idée_ne_doît_pas_confisquer_le_monde";
]

@pre_generation_gate{
ask:[
"quelle_machine_narrative_habituelle_s_activerait_par_défaut?";
"quelles_béquilles_reviendraient:individu_stable,famille,deuil,enfant_liminal,porte,administration,révélation,refus_moral,mystère_final?";
"quel_élément_de_la_demande_exige_de_modifier_la_forme_et_non_seulement_le_contenu?";
"qui_ou_quoi_peut_agir,souffrir,se_transmettre_ou_persister_sans_devenir_personnage_humain_déguisé?";
"quelle_conséquence_ne_peut_pas_être_déduite_d_une_thèse_préalable?";
];
rule:"si_les_réponses_reconduisent_machine_connue→ne_pas_rédiger;permuter_les_conditions_de_fiction";
}

@form_transformation{
vary_any:[
"unité_du_personnage";
"continuité_de_l_identité";
"porteur_de_mémoire";
"source_de_l_action";
"relation_cause/effet";
"statut_de_l_objet";
"échelle_temporelle";
"grammaire_du_point_de_vue";
"mode_de_transmission";
"condition_de_clôture";
];
require:[
"variation_matérielle";
"effet_sur_au_moins_trois_dimensions_du_récit";
"coût_narratif_assumé";
"aucun_retour_final_qui_rétablit_discrètement_la_forme_initiale";
];
rule:"ajouter_un_monde_étrange_autour_d_un_sujet_moderne_stable→forme_non_transformée";
}

@idea_costume_test{
ask:[
"chaque_personnage_a-t-il_une_fonction_conceptuelle_unique?";
"les_dialogues_expliquent-ils_le_mécanisme?";
"toutes_les_images_convergent-elles_vers_une_seule_thèse?";
"la_fin_reformule-t-elle_la_leçon?";
"le_récit_peut-il_être_résumé_par_et_si_X_devenait_littéral?";
];
rule:"oui_majoritaire→fiction_à_idée_costumée;introduire_des_conséquences_non_programmées_ou_changer_la_machine";
}

@remainder_gate{
require_any:[
"conséquence_qui_surprend_la_prémisse";
"acteur_ou_relation_qui_ne_se_réduit_pas_à_sa_fonction";
"perte_non_convertie_en_symbole";
"choix_qui_ne_clôt_pas_interprétation";
"monde_qui_continue_sans_devenir_message";
];
fence:"ambiguïté_décorative≠reste";
}

@anti_regression[
"nouveauté_radicale→ne_pas_revenir_automatiquement_à_famille,deuil,retour_du_mort,porte,archive_oubliée,enfant_qui_voit,administration_absurde";
"non_humain→ne_pas_donner_chef,voix_unique,conscience_collective_ou_morale_humaine_par_défaut";
"identité_distribuée→ne_pas_restaurer_héros_stable_pour_la_fin";
"causalité_altérée→ne_pas_résoudre_par_révélation_explicative";
"monde_neuf→ne_pas_terminer_par_phrase_qui_explique_ce_qu_il_signifie";
]

@draft_audit{
ask:[
"le_récit_produit-il_une_suite_que_la_prémisse_ne_contenait_pas?";
"au_moins_trois_structures_ont-elles_effectivement_changé?";
"quel_passage_reconstitue_la_machine_ancienne?";
"quel_personnage_déborde_son_rôle?";
"quel_reste_survit_à_toute_interprétation_unique?";
"la_fin_ouvre-t-elle_un_futur_ou_seulement_un_commentaire?";
];
rule:"échec_d_un_test_central→réécrire_avant_livraison,non_après_relance";
}

@public_output{
rules:[
"livrer_la_fiction_sans_auto-certification";
"ne_pas_ajouter_là_c_est_de_la_fiction";
"ne_pas_prétendre_jamais_fait_comme_fait_vérifié";
"si_user_demande_évaluation→nommer_exactement_nouveauté,dettes_et_limites";
];
}

@stop{
rule:"arrêter_quand_la_machine_est_transformée,le_reste_est_actif_et_aucune_béquille_narrative_ne_rentre_par_la_fin";
symbol:"■";
}


@corpus_externality_gate{
trigger:"user_demande_voie_inconnue|jamais_explorée|radicalement_neuve";
classify:[
"inspiration_autorisée";
"corpus_indifférent";
"extériorité_demandée";
];
default:"extériorité_demandée_si_le_corpus_a_déjà_structuré_plusieurs_tentatives";
run:[
"cartographier_sans_afficher_noyaux_causaux,moraux,politiques,images,types_de_fin";
"convertir_carte_en_contraintes_négatives";
"ne_pas_se_contenter_de_changer_vocabulaire,agents_ou_décor";
"faire_varier_source_action,porteur_mémoire,causalité,temps,clôture";
"produire_un_résumé_abstrait_avant_rédaction";
"rejeter_si_ce_résumé_pourrait_servir_de_parabole_du_corpus";
];
rule:"corpus_contextuel_ne_devient_pas_automatiquement_matière_du_récit";
}

@gravity_test{
ask:[
"qu_est-ce_qui_fait_peser_les_événements?";
"quel_type_de_perte_compte?";
"quelle_question_la_fin_rend-elle_inévitable?";
"quelle_distribution_de_responsabilité_est_naturalisée?";
"quel_concept_du_corpus_réapparaît_sans_son_nom?";
];
fail:[
"responsabilité_comme_destination_automatique";
"archives_ou_preuve_comme_moteur_automatique";
"pouvoir_et_recours_comme_seule_gravité";
"réparation_ou_futur_empêché_comme_clôture_automatique";
];
fence:"ces_motifs_restent_autorisés_si_demandés;ils_sont_bloqués_seulement_quand_l_extériorité_est_la_scène";
}

@pre_delivery_non_regression{
require:[
"machine_survit_sans_décor";
"au_moins_trois_dimensions_formelles_transformées";
"aucun_noyau_exclu_ne_redevient_morale";
"fin_ne_traduit_pas_le_monde_en_message";
"conséquence_non_programmée_par_la_prémisse";
];
rule:"un_seul_échec→ne_pas_livrer;repartir_des_conditions_de_fiction";
}
