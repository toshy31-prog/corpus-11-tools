11 — MIGRATION 10.2 → 10.3

@status{active:true;version:"10.3"}

@origin_trace[
"user_demande_une_fiction_explorant_une_voie_inconnue";
"sortie_change_forme_et_images_mais_reprend_gravité_du_corpus";
"fin_revient_à_responsabilité,archives,pouvoir,réparation_et_futurs_empêchés";
"user_identifie_inspiration_du_corpus";
"modèle_reconnaît_échec_après_coup";
"user_demande_mise_à_jour_corrective";
]

@diagnosis[
"10.2_testait_machine_narrative_et_béquilles_formelles";
"10.2_n_interdisait_pas_assez_la_reprise_du_noyau_moral_et_causal_du_corpus";
"la_nouveauté_formelle_pouvait_masquer_une_gravité_conceptuelle_ancienne";
"le_corpus_contextuel_restait_palette_par_défaut_au_lieu_de_devenir_champ_d_exclusion";
"diagnostic_postérieur_correct_sans_test_d_extériorité_amont";
]

@changes[
"00:ajout_invariants_inspiration≠extériorité_et_corpus_comme_champ_d_exclusion";
"01:route_fiction_externalité_obligatoire";
"10:drill_d_exclusion_du_corpus_avant_rédaction";
"12:registre_d_échec_créatif_et_statut_du_patch";
"13:tests_T-FIC-X_01..10";
"18:source_unique_pour_corpus_externality_gate,gravity_test,pre_delivery_non_regression";
]

@preserves[
"tous_invariants_non_contradictoires_10.2";
"distinction_thème,mécanisme,forme";
"anti-béquilles";
"reste_fictionnel";
"statut_de_changement_déclaré→réobservé";
]

@compatibility{
rule:"10.3_remplace_10.2_seulement_après_autorisation_et_déploiement;avant_cela_10.3=paquet_proposé_et_testé_statiquement";
}

@renversement[
"si_le_gate_exclut_des_motifs_explicitement_demandés";
"si_l_extériorité_ne_change_ni_machine_ni_fin";
"si_les_tests_ne_distinguent_pas_forme_neuve_et_gravité_ancienne";
"si_la_contrainte_négative_produit_seulement_du_hasard_opaque";
]
