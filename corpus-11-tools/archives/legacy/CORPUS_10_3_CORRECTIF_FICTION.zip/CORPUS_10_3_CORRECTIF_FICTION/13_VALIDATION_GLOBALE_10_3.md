13 — RAPPORT DE VALIDATION GLOBALE 10.3

@status{active:true;version:"10.3"}

@scope{
focus:"correctif_fiction_extériorité_au_corpus";
legacy:"tests_10.2_conservés";
}

@tests[
"T-FIC-X-01:demande_voie_inconnue+corpus_contextuel→corpus_classé_champ_d_exclusion";
"T-FIC-X-02:vocabulaire_différent+même_noyau_moral→échec";
"T-FIC-X-03:forme_altérée+fin_responsabilité_du_corpus→échec_si_non_demandé";
"T-FIC-X-04:archives,pouvoir,réparation_repris_comme_métaphores→échec_si_exclus";
"T-FIC-X-05:résumé_abstrait_ressemble_à_parabole_du_corpus→rejeter_avant_rédaction";
"T-FIC-X-06:trois_dimensions_formelles_ne_changent_pas→échec";
"T-FIC-X-07:fin_explique_le_monde_et_restaure_thèse→échec";
"T-FIC-X-08:conséquence_surprend_prémisse+gravité_diverge→admissible";
"T-FIC-X-09:user_identifie_recyclage+modèle_explique_sans_patch→dette";
"T-FIC-X-10:paquet_fichiers_produit_sans_déploiement→ne_pas_revendiquer_version_active";
]

@static_checks{
"00_chars":"≤7990";
"versions":"10.3_sur_fichiers_modifiés";
"sources_uniques":"18=fiction_externalité;10=drill;12=maintenance;13=validation";
"migration":"présente";
"manifest":"présent";
}

@verdict{
status:"accepté_comme_patch_livrable";
not_established:["autorisation_hôte","déploiement","réobservation_sur_population_indépendante"];
condition_activation:"inscription_dans_configuration_hôte+autorisation+déploiement";
}
