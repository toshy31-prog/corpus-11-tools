import { SCOUT_DIRECTIONS, createScoutPatch } from "./scout-parameters.mjs";
import { mixDirectionGroups } from "./direction-mixer.mjs";
import { compareMusic, isOtherArtist } from "./music-sorting.mjs";

const INACTIVE = new Set(["paused", "explored", "dismissed"]);
const list = value => Array.isArray(value) ? value : [];
const integer = (value, fallback = 0) => Number.isFinite(Number(value))
  ? Math.max(0, Math.floor(Number(value))) : fallback;
const validItem = item => item && typeof item.id === "string" && item.id.trim() && item.id === item.id.trim();

export function reconcileDirectionFilter(filter, routes = []) {
  return routes.some(route => route.id === filter && route.enabled) ? filter : "";
}

export function emptyMixMessage(view = {}) {
  const selected = (view.routes || []).filter(route => route.enabled && (!view.directionFilter || route.id === view.directionFilter));
  if (view.busy) return "Recherche en cours. Les résultats arriveront ici ; vous pouvez interrompre l’attente.";
  if (!selected.length) return "Activez une direction dans les réglages pour commencer.";
  if (selected.some(route => route.state === "error" || route.state === "unavailable")) return "La recherche n’a pas abouti : une source est indisponible. Réessayez les sources ; aucun résultat ne signifie pas ici aucun lien.";
  if (selected.some(route => route.state === "confirmation")) return "L’identité du départ doit être précisée avant de consulter ces catalogues.";
  if (selected.some(route => route.distantHidden)) return "Des liens éditoriaux larges sont disponibles. Activez « Inclure les liens éloignés » pour les consulter, ou recherchez d’autres directions.";
  if (selected.some(route => route.artistHidden)) return "Aucun autre artiste identifié dans ces pistes chargées. Désactivez le filtre ou recherchez davantage ; les artistes inconnus sont aussi écartés.";
  if (selected.some(route => route.loaded)) return "Vous avez parcouru les pistes admissibles chargées. Recommencez les pages de ce départ ou recherchez d’autres pistes.";
  if (selected.some(route => route.state === "partial")) return "La recherche est incomplète. Reprenez les sources ; les détails des directions précisent ce qui manque.";
  if (selected.some(route => route.canLoad)) return "Lancez la recherche pour consulter les directions activées.";
  return "Aucun lien trouvé dans les sources consultées. Vous pouvez changer de départ ; cela ne prouve pas l’absence de liens ailleurs.";
}

// This is presentation history, NOT listening history or an identity claim.
export function mixHistoryForSeed(history, seedId) {
  return {
    seedId: String(seedId || ""),
    turn: history?.seedId === seedId ? integer(history.turn) : 0,
    seenIds: history?.seedId === seedId
      ? [...new Set(list(history.seenIds).filter(id => typeof id === "string"))] : []
  };
}

export function consumeMixPage(history, view) {
  const previous = mixHistoryForSeed(history, view?.seedId);
  if (!view?.seedId || !list(view.items).length) return previous;
  return {
    ...previous,
    turn: previous.turn + 1,
    seenIds: [...new Set([...previous.seenIds, ...view.items.map(item => item.id)])]
  };
}

/**
 * Adapter around existing direction groups and the existing selector.
 * The selector is injected, so there is no second discovery algorithm here.
 * No graph, collection, source request or identity resolver is accessible.
 *
 * Ordering: selectDiscoveries per route -> existing mixer -> weighted interleave.
 * Do NOT pass the mixed queue back through an unweighted global selector.
 */
export function buildScoutMixView({
  seedId = "", groups = {}, front = null, guidance = {}, patch = {}, history = {}, routePlans = {},
  focus = "breadth", seedArtist = "", seedArtistIds = [], limit = 6, directionFilter = "", select
} = {}) {
  if (typeof select !== "function") throw new TypeError("Le sélecteur Scout est requis.");
  const controls = createScoutPatch(patch);
  const explicitSpread = Boolean(patch && typeof patch === "object" && ((patch.shape && Object.hasOwn(patch.shape, "spread")) || Object.hasOwn(patch, "spread")));
  const effectiveSpread = explicitSpread ? controls.shape.spread : focus === "depth" ? 0 : 1;
  const effectiveControls = { ...controls, shape: { ...controls.shape, spread: effectiveSpread } };
  const currentHistory = mixHistoryForSeed(history, seedId);
  const canFilterArtists = Boolean(seedArtistIds.length || String(seedArtist).trim());
  const artistFilterApplied = controls.otherArtistsOnly && canFilterArtists;
  const compare = (a, b) => compareMusic(a, b, controls.sort, { shuffleKey: controls.shuffleKey });
  const excluded = new Set(currentHistory.seenIds);
  for (const group of Object.values(groups || {})) {
    for (const id of list(group?.seenIds)) excluded.add(id);
  }
  if (seedId) excluded.add(seedId);

  const prepared = {};
  const originals = new Map();
  const directLinkedIds = new Set(Object.entries(groups).filter(([id]) => ["remix", "featuring", "alias", "compilation"].includes(id) && controls.directionWeights[id] > 0).flatMap(([, group]) => list(group.items).filter(item => !item.relationship?.distant).map(item => item.id)));
  const routes = SCOUT_DIRECTIONS.map(({ id, label }) => {
    const group = groups?.[id];
    const branch = list(front?.branches).find(value => value.direction === id);
    const plan = routePlans?.[id] || null;
    const blocked = plan && ["not_applicable", "source_gap"].includes(plan.implementation);
    const weight = effectiveControls.directionWeights[id];
    const paused = INACTIVE.has(branch?.status) || INACTIVE.has(group?.status);
    const confirmation = group?.coverage?.state === "needs_confirmation" ||
      (guidance?.state === "needs_confirmation" && list(guidance.directions).includes(id));
    const raw = list(group?.items).filter(validItem);
    const nearby = raw.filter(item => controls.includeDistant || !item.relationship?.distant || directLinkedIds.has(item.id) || item.anchor?.id === seedId);
    const eligibleRaw = artistFilterApplied ? nearby.filter(item => isOtherArtist(item, { name: seedArtist, artistIds: seedArtistIds })) : nearby;
    const enabled = Boolean(seedId && weight > 0 && !paused && !confirmation && !blocked);
    const unavailable = group?.coverage?.state === "source_unavailable";
    const operationalState = !seedId ? "idle" : !weight ? "muted" : paused ? "paused" :
      confirmation ? "confirmation" : group?.loading ? "loading" : group?.error ? "error" :
      unavailable ? "unavailable" : raw.length ? "ready" :
      group?.coverage?.complete && !group?.coverage?.hasMore ? "empty" :
      group?.coverage?.state && group.coverage.state !== "not_checked" ? "partial" : "pending";
    const state = blocked
      ? plan.implementation === "not_applicable" ? "n/a" : "unsupported"
      : operationalState === "pending" && plan?.implementation === "orchestration_gap" ? "mediated"
        : operationalState === "pending" && plan?.implementation === "implemented_local" && plan?.mode === "aggregate" ? "aggregate"
          : operationalState;
    let selected = [];
    if (enabled && raw.length) {
      // Isolate even a selector that updates its candidate objects.
      const choices = select(structuredClone(eligibleRaw), {
        exclude: [...excluded], limit: raw.length,
        focus: effectiveSpread === 0 ? "depth" : "breadth",
        spread: effectiveSpread,
        turn: currentHistory.turn + integer(group?.turn), seedArtist
      });
      if (!Array.isArray(choices)) throw new TypeError("Le sélecteur Scout doit retourner une liste.");
      const byId = new Map(raw.map(item => [item.id, item]));
      const seen = new Set();
      selected = choices.filter(item => validItem(item) && byId.has(item.id) &&
        !excluded.has(item.id) && !seen.has(item.id) && seen.add(item.id));
      selected.sort(compare);

      originals.set(id, byId);
      if (!directionFilter || directionFilter === id) prepared[id] = { items: selected };
    }
    const canLoad = enabled && !group?.loading && (!group || Boolean(group.error) || unavailable ||
      Boolean(group.coverage?.hasMore) || (!raw.length && !group.coverage?.complete));
    const loadKind = !canLoad ? null : group?.error || unavailable ? "retry" :
      group?.coverage?.hasMore ? "continue" : "open";
    return {
      id, label, weight, state, enabled, plan,
      loaded: raw.length, eligible: selected.length, presented: 0, distantHidden: raw.length - nearby.length, artistHidden: nearby.length - eligibleRaw.length,
      distinctCurators: id === "curator"
        ? new Set(raw.map(item => String(item.channelId || item.anchor?.id || item.channelTitle || "")).filter(Boolean)).size
        : 0,
      distinctArtists: new Set(raw.map(item => String(item.artist || "").trim()).filter(Boolean)).size,
      frontierState: front?.frontier?.byDirection?.[id]?.state || "",
      frontierTargets: Number(front?.frontier?.byDirection?.[id]?.targets || 0),
      frontierBranches: Number(front?.frontier?.byDirection?.[id]?.firstBranches || 0),
      frontierMaxDepth: Number(front?.frontier?.byDirection?.[id]?.maxObservedDepth || 0),
      canLoad, loadKind,
      message: String(group?.error || group?.coverage?.message || ""),
      selection: group?.coverage?.selection || null,
      stopReason: group?.coverage?.selection?.stopReason || "",
      hasMore: Boolean(group?.coverage?.hasMore),
      complete: Boolean(group?.coverage?.complete),
      loading: Boolean(group?.loading)
    };
  });

  // Exact IDs only across directions: names do not become identity joins.
  const mixed = mixDirectionGroups(prepared, { patch: effectiveControls, exclude: [...excluded] });
  const byId = new Map(mixed.map(item => [item.id, item]));
  let queues = routes.filter(route => prepared[route.id]?.items.length).map(route => ({
    ...route, index: 0, served: 0, items: prepared[route.id].items
  }));
  const picked = new Set();
  const items = [];
  const max = Math.min(60, integer(limit, 6));
  // Diversity is a preference within this page, never a deletion from the
  // remaining pool. A focused route can be browsed in full. In a mixed page,
  // prefer other sources, then fill spare places with the remaining uploads.
  const curatorCap = !directionFilter && queues.length > 1
    ? 1 + Math.floor((1 - effectiveSpread) * Math.max(0, max - 1)) : Infinity;
  const curatorCounts = new Map();
  const albumCounts = new Map(), artistCounts = new Map();
  // Individual credits, not the whole 'X & Y' display string. These keys
  // diversify presentation only; they never merge catalogue identities.
  const artistKeys = item => [...new Set([...(item.artistIds || []).map(id => `id:${id}`),
    ...String(item.artist || "").split(/\s*(?:&|;|\bfeat\.?\s)\s*/i).map(name => name.trim().toLocaleLowerCase("fr")).filter(Boolean).map(name => `name:${name}`)])];
  const curatorKey = item => String(item.channelId || item.anchor?.externalIds?.youtube || item.anchor?.id || item.channelTitle || "unknown-curator");
  // When a page is smaller than the number of enabled routes, rotate ties
  // on the NEXT gesture so the last routes cannot starve forever.
  const rotation = queues.length ? (currentHistory.turn * Math.max(1, max)) % queues.length : 0;
  queues = [...queues.slice(rotation), ...queues.slice(0, rotation)];

  // Virtual finish times implement a deterministic relative route mix.
  // Equal weights alternate routes; a larger weight receives more slots.
  while (items.length < max) {
    let winner = null;
    for (const respectDiversity of [true, false]) {
      for (const queue of queues) {
        const item = queue.items.find(candidate => !picked.has(candidate.id) &&
          (!respectDiversity || ((queue.id !== "curator" || (curatorCounts.get(curatorKey(candidate)) || 0) < curatorCap) &&
            (!effectiveSpread || !candidate.releaseId || !albumCounts.has(candidate.releaseId)) &&
            (!effectiveSpread || artistKeys(candidate).every(key => (artistCounts.get(key) || 0) < 2)))));
        if (!item) continue;
        const finish = (queue.served + 1) / queue.weight;
        if (!winner || (controls.sort === "explore" ? finish < winner.finish : compare(item, winner.item) < 0)) winner = { queue, finish, item };
      }
      if (winner) break;
    }
    if (!winner) break;
    const queue = winner.queue;
    const item = winner.item;
    if (queue.id === "curator") curatorCounts.set(curatorKey(item), (curatorCounts.get(curatorKey(item)) || 0) + 1);
    if (item.releaseId) albumCounts.set(item.releaseId, (albumCounts.get(item.releaseId) || 0) + 1);
    for (const key of artistKeys(item)) artistCounts.set(key, (artistCounts.get(key) || 0) + 1);
    queue.served++;
    picked.add(item.id);
    const merged = byId.get(item.id);
    const observations = list(merged?.routing?.routes).map(route => ({
      direction: route.direction, weight: route.weight,
      item: originals.get(route.direction)?.get(item.id)
    })).filter(observation => observation.item);
    items.push({
      ...item,
      routing: {
        ...merged.routing,
        selectedVia: queue.id,
        // Preserve EACH observation, not only the first route's proof.
        observations
      }
    });
    routes.find(route => route.id === queue.id).presented++;
  }
  return {
    seedId,
    canFilterArtists,
    artistFilterApplied,
    patch: effectiveControls,
    items,
    routes,
    candidates: mixed.length,
    hasNextPage: items.length > 0 && mixed.length > items.length,
    directionFilter,
    canRewind: excluded.size > (seedId ? 1 : 0),
    history: currentHistory,
    discovery: {
      depthLimit: Number(front?.frontier?.depthLimit || effectiveControls.shape?.depth || 0),
      maxObservedDepth: Number(front?.frontier?.maxObservedDepth || 0),
      distinctTargets: Number(front?.frontier?.distinctTargets || 0),
      distinctFirstBranches: Number(front?.frontier?.distinctFirstBranches || 0),
      distinctPaths: Number(front?.frontier?.distinctPaths || 0)
    }
  };
}

/** Sequential, explicit loading. A changed departure or cancelled run wins. */
export async function runScoutMixLoad({ directions, isCurrent, isEnabled, load, onProgress = () => {} }) {
  let completed = 0;
  for (const direction of directions) {
    if (!isCurrent()) return { completed, cancelled: true };
    if (!isEnabled(direction)) continue;
    await load(direction);
    if (!isCurrent()) return { completed, cancelled: true };
    completed++;
    onProgress(completed);
  }
  return { completed, cancelled: false };
}
