// Display/search credit boundaries, never a catalogue identity assertion.
export function splitArtistNames(value = "") {
  return [...new Set(String(value).normalize("NFC")
    .replace(/\((?:electronics?|soprano sax|tenor sax|composer|vocals?|producer|guitar|drums|bass)\)/gi, "")
    .split(/\s*(?:;|,|\s&\s|\s\+\s|\bfeat(?:uring)?\.?\s|\bft\.?\s)\s*/i)
    .map(name => name.trim()).filter(Boolean))];
}

export function recordingArtistHints(value = "") {
  const names = splitArtistNames(value);
  return [...new Set([String(value).trim(), ...names])].filter(Boolean).slice(0, 4);
}

export async function searchCreditChoices(value, search) {
  // Also retain the full query: separators can belong to a band's name.
  const names = [...new Set([String(value).trim(), ...splitArtistNames(value)])].filter(Boolean).slice(0, 5);
  const replies = await Promise.allSettled(names.map(name => search(name)));
  const candidates = new Map(), sourceStates = {};
  for (const reply of replies) {
    if (reply.status !== "fulfilled") continue;
    for (const candidate of reply.value?.candidates || []) candidates.set(candidate.id, candidate);
    for (const [source, state] of Object.entries(reply.value?.sourceStates || {})) {
      if (!sourceStates[source] || state !== "ok") sourceStates[source] = state;
    }
  }
  if (replies.some(reply => reply.status === "rejected")) sourceStates.search = "unavailable";
  return { candidates: [...candidates.values()], sourceStates };
}
